<?php
ob_start();
session_start();

require_once dirname(__DIR__) . "/config/db.php";

$error = "";

if(isset($_POST['login'])){

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass  = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result && $result->num_rows > 0){

        $user = $result->fetch_assoc();

        if(password_verify($pass, $user['password'])){

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['role'] = $user['role'] ?? 'user';

            header("Location: ../dashboard.php");
            exit();

        } else {
            $error = "Invalid password!";
        }

    } else {
        $error = "Email not registered!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Smart Energy Saver | Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at 20% 30%, #0a0f1e, #03060c);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
        }

        /* animated energy particles background */
        .energy-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .energy-bg span {
            position: absolute;
            display: block;
            width: 4px;
            height: 4px;
            background: #00f2ff;
            border-radius: 50%;
            box-shadow: 0 0 12px #00e0ff, 0 0 20px #00c3ff;
            opacity: 0.4;
            animation: floatParticle 12s infinite linear;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) scale(0.5);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            80% {
                opacity: 0.8;
            }
            100% {
                transform: translateY(-20vh) scale(1.2);
                opacity: 0;
            }
        }

        /* main glassmorphic card */
        .login-container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 460px;
            margin: 1.5rem;
        }

        .brand-header {
            text-align: center;
            margin-bottom: 1.8rem;
        }

        .brand-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e2a3a, #0b1120);
            padding: 0.9rem;
            border-radius: 3rem;
            box-shadow: 0 8px 20px rgba(0, 242, 255, 0.2), inset 0 1px 0 rgba(255,255,255,0.05);
            margin-bottom: 1rem;
        }

        .brand-icon i {
            font-size: 2.8rem;
            filter: drop-shadow(0 0 6px #00f2ff);
            background: linear-gradient(135deg, #aaffff, #2ad4ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        h1 {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(120deg, #ffffff, #9efff0);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: -0.3px;
            text-shadow: 0 2px 5px rgba(0,242,255,0.2);
        }

        .tagline {
            color: #8e9aaf;
            font-weight: 500;
            font-size: 0.85rem;
            margin-top: 0.25rem;
            letter-spacing: 0.5px;
        }

        /* card */
        .card {
            background: rgba(12, 20, 30, 0.65);
            backdrop-filter: blur(14px);
            border-radius: 2rem;
            border: 1px solid rgba(0, 242, 255, 0.25);
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.5), 0 0 20px rgba(0, 242, 255, 0.1);
            padding: 2rem 2rem 2.2rem;
            transition: all 0.3s ease;
        }

        .card:hover {
            border-color: rgba(0, 242, 255, 0.5);
            box-shadow: 0 30px 50px rgba(0, 0, 0, 0.6), 0 0 28px rgba(0, 242, 255, 0.2);
        }

        .input-group {
            margin-bottom: 1.8rem;
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            color: #2ad4ff;
            text-shadow: 0 0 3px #00ccff;
            transition: 0.2s;
            z-index: 2;
        }

        .input-group input {
            width: 100%;
            background: rgba(2, 10, 22, 0.7);
            border: 1.5px solid #2a3b4e;
            border-radius: 2rem;
            padding: 0.9rem 1rem 0.9rem 3rem;
            font-size: 1rem;
            font-weight: 500;
            color: #eef5ff;
            font-family: 'Inter', sans-serif;
            transition: all 0.25s ease;
            outline: none;
            letter-spacing: 0.3px;
        }

        .input-group input:focus {
            border-color: #00f2ff;
            box-shadow: 0 0 12px rgba(0, 242, 255, 0.4);
            background: rgba(6, 18, 30, 0.9);
        }

        .input-group input::placeholder {
            color: #6c7c94;
            font-weight: 400;
            font-size: 0.9rem;
        }

        /* neon glow button */
        .login-btn {
            width: 100%;
            background: linear-gradient(95deg, #00c3ff, #0077ff);
            border: none;
            padding: 0.9rem;
            border-radius: 2.5rem;
            font-weight: 700;
            font-size: 1.1rem;
            font-family: 'Inter', sans-serif;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            transition: 0.25s;
            box-shadow: 0 5px 15px rgba(0, 150, 255, 0.3);
            letter-spacing: 0.5px;
            margin-top: 0.5rem;
        }

        .login-btn i {
            font-size: 1.2rem;
            transition: transform 0.2s;
        }

        .login-btn:hover {
            background: linear-gradient(95deg, #00d4ff, #0088ff);
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(0, 200, 255, 0.5);
        }

        .login-btn:hover i {
            transform: translateX(4px);
        }

        /* error message styling */
        .error-message {
            background: rgba(255, 70, 90, 0.15);
            backdrop-filter: blur(8px);
            border-left: 4px solid #ff4d6d;
            padding: 0.8rem 1rem;
            border-radius: 1rem;
            margin-bottom: 1.8rem;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #ffb3bb;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .error-message i {
            font-size: 1.2rem;
            color: #ff6b8b;
        }

        .info-footer {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.8rem;
            color: #8f9bb3;
            border-top: 1px dashed rgba(0, 242, 255, 0.3);
            padding-top: 1.5rem;
        }

        .info-footer a {
            color: #4cdbff;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }

        .info-footer a:hover {
            text-shadow: 0 0 5px #00f2ff;
            letter-spacing: 0.3px;
        }

        /* energy pulse effect on card */
        @keyframes subtlePulse {
            0% { border-color: rgba(0, 242, 255, 0.2); }
            100% { border-color: rgba(0, 242, 255, 0.5); }
        }

        /* responsive */
        @media (max-width: 500px) {
            .card {
                padding: 1.5rem;
            }
            h1 {
                font-size: 1.7rem;
            }
            .brand-icon i {
                font-size: 2.2rem;
            }
        }

        /* custom neon icons inside inputs */
        .input-group .fa-envelope, 
        .input-group .fa-lock {
            filter: drop-shadow(0 0 2px #0af);
        }
    </style>
</head>
<body>
<div class="energy-bg" id="particleCanvas"></div>

<div class="login-container">
    <div class="brand-header">
        <div class="brand-icon">
            <i class="fas fa-bolt"></i>
        </div>
        <h1>SMART ENERGY SAVER</h1>
        <div class="tagline">
            <i class="fas fa-leaf" style="font-size: 0.7rem;"></i> intelligent monitoring • eco efficiency
        </div>
    </div>

    <div class="card">
        <form method="POST" action="">
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email address" required autocomplete="email">
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required autocomplete="current-password">
            </div>
            <button type="submit" name="login" class="login-btn">
                <span>ACCESS DASHBOARD</span>
                <i class="fas fa-arrow-right-to-bracket"></i>
            </button>
        </form>
        <div class="info-footer">
            <i class="fas fa-microchip"></i> smart energy analytics • <a href="#">Forgot password?</a>
        </div>
    </div>
</div>

<script>
    
    (function createEnergyParticles() {
        const container = document.getElementById('particleCanvas');
        const particleCount = 80;
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('span');
            const size = Math.random() * 6 + 2;
            particle.style.width = size + 'px';
            particle.style.height = size + 'px';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDuration = Math.random() * 15 + 8 + 's';
            particle.style.animationDelay = Math.random() * 10 + 's';
            particle.style.background = `radial-gradient(circle, rgb(0, 255, 255), rgb(42, 110, 255))`;
            particle.style.boxShadow = `0 0 ${Math.random() * 10 + 4}px rgb(0, 170, 255)`;
            particle.style.opacity = Math.random() * 0.5 + 0.2;
            container.appendChild(particle);
        }
    })();

    const inputs = document.querySelectorAll('.input-group input');
    inputs.forEach(inp => {
        inp.addEventListener('focus', (e) => {
            e.target.parentElement.style.transform = 'translateX(3px)';
            e.target.parentElement.style.transition = '0.2s';
        });
        inp.addEventListener('blur', (e) => {
            e.target.parentElement.style.transform = 'translateX(0)';
        });
    });

    const brandIcon = document.querySelector('.brand-icon');
    if(brandIcon) {
        brandIcon.addEventListener('mouseenter', () => {
            brandIcon.style.transform = 'scale(1.02)';
            brandIcon.style.transition = '0.2s';
            brandIcon.style.boxShadow = '0 0 15px rgb(0, 170, 255)';
        });
        brandIcon.addEventListener('mouseleave', () => {
            brandIcon.style.transform = 'scale(1)';
            brandIcon.style.boxShadow = '0 8px 20px rgba(0, 242, 255, 0.2)';
        });
    }
</script>
</body>
</html>