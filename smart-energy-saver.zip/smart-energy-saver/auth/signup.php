<?php
include("../config/db.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Smart Energy Saver | Sign Up</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at 20% 30%, rgb(10, 15, 30), rgb(3, 6, 12));
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
        }

        .energy-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            overflow: hidden;
            pointer-events: none;
        }

        .energy-bg span {
            position: absolute;
            display: block;
            width: 4px;
            height: 4px;
            background: rgb(0, 242, 255);
            border-radius: 50%;
            box-shadow: 0 0 12px rgb(0, 224, 255), 0 0 20px rgb(0, 195, 255);
            opacity: 0.4;
            animation: floatParticle 12s infinite linear;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) scale(0.5);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            80% {
                opacity: 0.8;
            }
            100% {
                transform: translateY(-20vh) scale(1.2);
                opacity: 0;
            }
        }
        .signup-container {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 480px;
            margin: 1.5rem;
        }

        .brand-header {
            text-align: center;
            margin-bottom: 1.8rem;
        }

        .brand-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e2a3a, #0b1120);
            padding: 0.9rem;
            border-radius: 3rem;
            box-shadow: 0 8px 20px rgba(0, 242, 255, 0.2), inset 0 1px 0 rgba(255,255,255,0.05);
            margin-bottom: 1rem;
            transition: all 0.2s ease;
        }

        .brand-icon i {
            font-size: 2.8rem;
            filter: drop-shadow(0 0 6px rgb(0, 242, 255));
            background: linear-gradient(135deg, rgb(170, 255, 255), rgb(42, 212, 255));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        h1 {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(120deg, rgb(255, 255, 255), rgb(158, 255, 240));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: -0.3px;
            text-shadow: 0 2px 5px rgba(0,242,255,0.2);
        }

        .tagline {
            color: #8e9aaf;
            font-weight: 500;
            font-size: 0.85rem;
            margin-top: 0.25rem;
            letter-spacing: 0.5px;
        }

        .card {
            background: rgba(12, 20, 30, 0.65);
            backdrop-filter: blur(14px);
            border-radius: 2rem;
            border: 1px solid rgba(0, 242, 255, 0.25);
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.5), 0 0 20px rgba(0, 242, 255, 0.1);
            padding: 2rem 2rem 2.2rem;
            transition: all 0.3s ease;
        }

        .card:hover {
            border-color: rgba(0, 242, 255, 0.5);
            box-shadow: 0 30px 50px rgba(0, 0, 0, 0.6), 0 0 28px rgba(0, 242, 255, 0.2);
        }

        .input-group {
            margin-bottom: 1.8rem;
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            color: rgb(42, 212, 255);
            text-shadow: 0 0 3px rgb(0, 204, 255);
            transition: 0.2s;
            z-index: 2;
        }

        .input-group input {
            width: 100%;
            background: rgba(2, 10, 22, 0.7);
            border: 1.5px solid rgb(42, 59, 78);
            border-radius: 2rem;
            padding: 0.9rem 1rem 0.9rem 3rem;
            font-size: 1rem;
            font-weight: 500;
            color: #eef5ff;
            font-family: 'Inter', sans-serif;
            transition: all 0.25s ease;
            outline: none;
            letter-spacing: 0.3px;
        }

        .input-group input:focus {
            border-color: #00f2ff;
            box-shadow: 0 0 12px rgba(0, 242, 255, 0.4);
            background: rgba(6, 18, 30, 0.9);
        }

        .input-group input::placeholder {
            color: #6c7c94;
            font-weight: 400;
            font-size: 0.9rem;
        }

        .signup-btn {
            width: 100%;
            background: linear-gradient(95deg, #00c3ff, #0077ff);
            border: none;
            padding: 0.9rem;
            border-radius: 2.5rem;
            font-weight: 700;
            font-size: 1.1rem;
            font-family: 'Inter', sans-serif;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            cursor: pointer;
            transition: 0.25s;
            box-shadow: 0 5px 15px rgba(0, 150, 255, 0.3);
            letter-spacing: 0.5px;
            margin-top: 0.5rem;
        }

        .signup-btn i {
            font-size: 1.2rem;
            transition: transform 0.2s;
        }

        .signup-btn:hover {
            background: linear-gradient(95deg, #00d4ff, #0088ff);
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(0, 200, 255, 0.5);
        }

        .signup-btn:hover i {
            transform: translateX(4px);
        }

        /* error / success message styling */
        .message-box {
            background: rgba(255, 70, 90, 0.15);
            backdrop-filter: blur(8px);
            border-left: 4px solid #ff4d6d;
            padding: 0.8rem 1rem;
            border-radius: 1rem;
            margin-bottom: 1.8rem;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #ffb3bb;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .message-box i {
            font-size: 1.2rem;
            color: #ff6b8b;
        }

        .success-message {
            background: rgba(0, 255, 200, 0.12);
            border-left: 4px solid #2affb6;
            color: #a0ffdd;
        }

        .success-message i {
            color: #3effc0;
        }

        .info-footer {
            margin-top: 2rem;
            text-align: center;
            font-size: 0.8rem;
            color: #8f9bb3;
            border-top: 1px dashed rgba(0, 242, 255, 0.3);
            padding-top: 1.5rem;
        }

        .info-footer a {
            color: #4cdbff;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }

        .info-footer a:hover {
            text-shadow: 0 0 5px #00f2ff;
            letter-spacing: 0.3px;
        }

        /* responsive */
        @media (max-width: 500px) {
            .card {
                padding: 1.5rem;
            }
            h1 {
                font-size: 1.7rem;
            }
            .brand-icon i {
                font-size: 2.2rem;
            }
        }

        /* input group icon neon */
        .input-group .fa-user,
        .input-group .fa-envelope,
        .input-group .fa-lock {
            filter: drop-shadow(0 0 2px #0af);
        }

        /* password strength hint (optional extra style) */
        .password-hint {
            font-size: 0.7rem;
            color: #7e8aa8;
            margin-top: 0.4rem;
            margin-left: 1rem;
            display: flex;
            align-items: center;
            gap: 6px;
        }
    </style>
</head>
<body>
<div class="energy-bg" id="particleCanvas"></div>

<div class="signup-container">
    <div class="brand-header">
        <div class="brand-icon">
            <i class="fas fa-solar-panel"></i>
        </div>
        <h1>SMART ENERGY SAVER</h1>
        <div class="tagline">
            <i class="fas fa-charging-station" style="font-size: 0.7rem;"></i> join the green revolution • smart analytics
        </div>
    </div>

    <div class="card">
        <?php
      
        $error_msg = '';
        $success_msg = '';

        if(isset($_POST['signup'])){
         
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];

            if(empty($name) || empty($email) || empty($password)) {
                $error_msg = "All fields are required!";
            } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error_msg = "Please enter a valid email address.";
            } elseif(strlen($password) < 6) {
                $error_msg = "Password must be at least 6 characters long.";
            } else {
              
                $check_sql = "SELECT id FROM users WHERE email = '$email'";
                $check_result = $conn->query($check_sql);
                
                if($check_result && $check_result->num_rows > 0) {
                    $error_msg = "Email already registered. Please use a different email or login.";
                } else {
                  
                    $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_pass')";
                    
                    if($conn->query($sql) === TRUE) {
                        $success_msg = "Account created successfully! Redirecting to login...";
                     
                        echo '<meta http-equiv="refresh" content="2;url=login.php">';
                    } else {
                        $error_msg = "Database error: " . $conn->error;
                    }
                }
            }
            
            if(!empty($error_msg)) {
                echo '<div class="message-box"><i class="fas fa-exclamation-triangle"></i> <span>' . htmlspecialchars($error_msg) . '</span></div>';
            }
            if(!empty($success_msg)) {
                echo '<div class="message-box success-message"><i class="fas fa-check-circle"></i> <span>' . htmlspecialchars($success_msg) . '</span></div>';
            }
        }
        ?>
        <form method="POST" action="" id="signupForm">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="name" placeholder="Full name" required autocomplete="name" value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
            </div>
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email address" required autocomplete="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="password" placeholder="Password (min. 6 characters)" required autocomplete="new-password">
            </div>
            <div class="password-hint">
                <i class="fas fa-shield-alt" style="font-size: 0.65rem;"></i> 
                <span>Use 6+ characters for strong security</span>
            </div>
            <button type="submit" name="signup" class="signup-btn">
                <span>CREATE ACCOUNT</span>
                <i class="fas fa-user-plus"></i>
            </button>
        </form>
        <div class="info-footer">
            <i class="fas fa-arrow-left"></i> Already have an account? <a href="login.php">Sign in here</a>
            <div style="margin-top: 8px; font-size: 0.7rem;">
                <i class="fas fa-bolt"></i> track energy • reduce carbon footprint
            </div>
        </div>
    </div>
</div>

<script>

    (function createEnergyParticles() {
        const container = document.getElementById('particleCanvas');
        if(!container) return;
        const particleCount = 80;
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('span');
            const size = Math.random() * 6 + 2;
            particle.style.width = size + 'px';
            particle.style.height = size + 'px';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDuration = Math.random() * 15 + 8 + 's';
            particle.style.animationDelay = Math.random() * 10 + 's';
            particle.style.background = `radial-gradient(circle, rgb(0, 255, 255), rgb(42, 110, 255))`;
            particle.style.boxShadow = `0 0 ${Math.random() * 10 + 4}px rgb(0, 170, 255)`;
            particle.style.opacity = Math.random() * 0.5 + 0.2;
            container.appendChild(particle);
        }
    })();

    const inputs = document.querySelectorAll('.input-group input');
    inputs.forEach(inp => {
        inp.addEventListener('focus', (e) => {
            e.target.parentElement.style.transform = 'translateX(3px)';
            e.target.parentElement.style.transition = '0.2s';
        });
        inp.addEventListener('blur', (e) => {
            e.target.parentElement.style.transform = 'translateX(0)';
        });
    });

    const brandIcon = document.querySelector('.brand-icon');
    if(brandIcon) {
        brandIcon.addEventListener('mouseenter', () => {
            brandIcon.style.transform = 'scale(1.02)';
            brandIcon.style.transition = '0.2s';
            brandIcon.style.boxShadow = '0 0 18px rgb(0, 170, 255)';
        });
        brandIcon.addEventListener('mouseleave', () => {
            brandIcon.style.transform = 'scale(1)';
            brandIcon.style.boxShadow = '0 8px 20px rgba(0, 242, 255, 0.2)';
        });
    }

    const passwordInput = document.getElementById('password');
    const hintSpan = document.querySelector('.password-hint span');
    if(passwordInput && hintSpan) {
        passwordInput.addEventListener('input', function() {
            const len = this.value.length;
            if(len === 0) {
                hintSpan.innerHTML = 'Use 6+ characters for strong security';
                hintSpan.style.color = 'rgb(126, 138, 168)';
            } else if(len < 6) {
                hintSpan.innerHTML = `⚠️ ${len}/6 characters - make it at least 6`;
                hintSpan.style.color = 'rgb(255, 170, 102)';
            } else {
                hintSpan.innerHTML = `✓ Strong (${len} characters)`;
                hintSpan.style.color = 'rgb(42, 255, 176)';
            }
        });
    }

    const form = document.getElementById('signupForm');
    if(form) {
        form.addEventListener('submit', function(e) {
            const pwd = document.getElementById('password').value;
            if(pwd.length < 6) {
                e.preventDefault();
                let errorDiv = document.querySelector('.message-box');
                if(!errorDiv || !errorDiv.classList.contains('success-message')) {
                    const msgBox = document.createElement('div');
                    msgBox.className = 'message-box';
                    msgBox.innerHTML = '<i class="fas fa-exclamation-triangle"></i> <span>Password must be at least 6 characters.</span>';
                    const cardBody = document.querySelector('.card');
                    const existingError = cardBody.querySelector('.message-box');
                    if(existingError && !existingError.classList.contains('success-message')) existingError.remove();
                    cardBody.insertBefore(msgBox, form);
                    setTimeout(() => { if(msgBox) msgBox.style.opacity = '0'; setTimeout(() => msgBox.remove(), 500); }, 3000);
                }
                return false;
            }
            return true;
        });
    }
</script>
</body>
</html>