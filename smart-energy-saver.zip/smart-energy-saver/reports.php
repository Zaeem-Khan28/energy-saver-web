<?php
include("includes/auth-check.php");
include("config/db.php");
include("includes/header.php");

$user_id = $_SESSION['user_id'];

$rate = 60;

$result = $conn->query("
    SELECT name, watts, hours, units, created_at
    FROM appliances
    WHERE user_id = '$user_id'
");

$total_units = 0;
$total_bill = 0;

$appliance_data = [];

while($row = $result->fetch_assoc()){
    $total_units += $row['units'];
    $appliance_data[] = $row;
}

$total_bill = $total_units * $rate;

$daily = $conn->query("
    SELECT DATE(created_at) as date, SUM(units) as total
    FROM appliances
    WHERE user_id = '$user_id'
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at) ASC
");
?>

<div class="container mt-4">
    <div class="mb-4">
        <h2 style="color: rgb(255, 255, 255); font-size: 28px; font-weight: 600;">
            <i class="fas fa-chart-line" style="color: rgb(0, 242, 255); margin-right: 12px;"></i>
            Energy Reports Dashboard
        </h2>
        <p style="color: rgb(154, 171, 194); margin-top: 8px;">Comprehensive analytics of your energy consumption patterns and insights</p>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-bolt"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Total Energy Usage</span>
                    <h3 class="stats-value"><?= round($total_units, 2) ?> <span>kWh</span></h3>
                    <span class="stats-trend">Total consumption</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-rupee-sign"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Estimated Bill</span>
                    <h3 class="stats-value">Rs. <?= number_format($total_bill, 2) ?></h3>
                    <span class="stats-trend">Monthly electricity cost</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-12">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-microchip"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Total Appliances</span>
                    <h3 class="stats-value"><?= count($appliance_data) ?> <span>Devices</span></h3>
                    <span class="stats-trend">Registered appliances</span>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-lg-7">
            <div class="section-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-plug"></i>
                    <h4>Appliance-wise Breakdown</h4>
                    <span class="badge"><?= count($appliance_data) ?> Items</span>
                </div>
                
                <?php if(count($appliance_data) > 0): ?>
                    <div class="table-wrapper">
                        <table class="professional-table">
                            <thead>
                                <tr>
                                    <th>Appliance Name</th>
                                    <th>Power (Watts)</th>
                                    <th>Hours/Day</th>
                                    <th>Daily Usage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($appliance_data as $a): ?>
                                <tr>
                                    <td>
                                        <div class="appliance-name">
                                            <i class="fas fa-microchip"></i>
                                            <?= htmlspecialchars($a['name']) ?>
                                        </div>
                                    </td>
                                    <td><?= number_format($a['watts'], 0) ?> W</td>
                                    <td><?= number_format($a['hours'], 1) ?> hrs</td>
                                    <td class="usage-value"><?= round($a['units'], 2) ?> kWh</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-plug"></i>
                        <p>No appliances found</p>
                        <a href="add_appliance.php" class="btn-primary-small">Add Your First Appliance</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="section-card trend-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-chart-line"></i>
                    <h4>Daily Energy Trend</h4>
                </div>
                
                <div class="trend-list">
                    <?php 
                    $has_data = false;
                    while($d = $daily->fetch_assoc()):
                        $has_data = true;
                        $percentage = ($d['total'] / max($total_units, 1)) * 100;
                    ?>
                        <div class="trend-item">
                            <div class="trend-date">
                                <i class="fas fa-calendar-day"></i>
                                <?= date("M d, Y", strtotime($d['date'])) ?>
                            </div>
                            <div class="trend-value">
                                <strong><?= round($d['total'], 2) ?> kWh</strong>
                            </div>
                            <div class="trend-bar">
                                <div class="trend-fill" style="width: <?= min($percentage, 100) ?>%;"></div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    
                    <?php if(!$has_data): ?>
                        <div class="empty-state-mini">
                            <i class="fas fa-chart-line"></i>
                            <p>No daily data available yet</p>
                            <span>Add appliances to see trends</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="section-card insights-card mb-5">
        <div class="section-header">
            <i class="fas fa-robot"></i>
            <h4>AI Energy Insights & Recommendations</h4>
        </div>
        
        <div class="insights-list">
            <?php if($total_units > 500): ?>
                <div class="insight-item critical">
                    <i class="fas fa-bell"></i>
                    <div>
                        <strong>Critical Alert!</strong>
                        <p>Your energy consumption (<?= round($total_units, 2) ?> kWh) is extremely high. Immediate optimization recommended.</p>
                    </div>
                </div>
            <?php elseif($total_units > 300): ?>
                <div class="insight-item warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>High Usage Detected</strong>
                        <p>Your consumption is above average. Consider reducing AC, heater, or other high-power appliances usage.</p>
                    </div>
                </div>
            <?php elseif($total_units > 0 && $total_units <= 300): ?>
                <div class="insight-item success">
                    <i class="fas fa-check-circle"></i>
                    <div>
                        <strong>Good Job!</strong>
                        <p>Your energy consumption is in an optimal range. Keep maintaining these habits.</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="insight-item info">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <strong>No Data Available</strong>
                        <p>Add appliances to get personalized energy insights and recommendations.</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="insight-item">
                <i class="fas fa-lightbulb"></i>
                <div>
                    <strong>Switch to LED Lighting</strong>
                    <p>Replace traditional bulbs with LED lights to save up to 80% on lighting costs.</p>
                </div>
            </div>
            
            <div class="insight-item">
                <i class="fas fa-plug"></i>
                <div>
                    <strong>Eliminate Standby Power</strong>
                    <p>Unplug electronics when not in use. Standby power can account for 5-10% of your bill.</p>
                </div>
            </div>
            
            <div class="insight-item">
                <i class="fas fa-thermometer-half"></i>
                <div>
                    <strong>Optimize AC Temperature</strong>
                    <p>Set AC to 24-26°C for maximum efficiency. Every degree lower increases energy use by 6-8%.</p>
                </div>
            </div>
            
            <?php if($total_units > 0): ?>
                <div class="insight-item savings-highlight">
                    <i class="fas fa-chart-line"></i>
                    <div>
                        <strong>Potential Savings</strong>
                        <p>By implementing these recommendations, you could save approximately <strong style="color: rgb(0, 255, 136);">Rs. <?= number_format($total_bill * 0.25, 2) ?></strong> per month!</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="eco-banner">
        <i class="fas fa-leaf"></i>
        <div>
            <h5>🌱 Green Energy Initiative</h5>
            <p>Every kilowatt saved helps build a sustainable future for Pakistan. Join the green revolution today!</p>
        </div>
    </div>
</div>

<style>
    .stats-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 18px;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .stats-card:hover {
        transform: translateY(-3px);
        border-color: rgba(0, 242, 255, 0.5);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }
    
    .stats-icon {
        width: 55px;
        height: 55px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .stats-icon i {
        font-size: 28px;
        color: rgb(0, 242, 255);
    }
    
    .stats-content {
        flex: 1;
    }
    
    .stats-label {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgb(255, 255, 255);
        font-weight: 500;
    }
    
    .stats-value {
        font-size: 28px;
        font-weight: 700;
        color: rgb(0, 242, 255);
        margin: 5px 0;
        line-height: 1.2;
    }
    
    .stats-value span {
        font-size: 14px;
        color: rgb(255, 255, 255);
        font-weight: 400;
    }
    
    .stats-trend {
        font-size: 11px;
        color: rgb(154, 171, 194);
    }
    
    .section-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .section-card:hover {
        border-color: rgba(0, 242, 255, 0.4);
    }
    
    .section-header {
        padding: 18px 24px;
        border-bottom: 1px solid rgba(0, 242, 255, 0.2);
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .section-header i {
        font-size: 20px;
        color: rgb(0, 242, 255);
    }
    
    .section-header h4 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0;
        flex: 1;
    }
    
    .badge {
        background: rgba(0, 242, 255, 0.15);
        color: rgb(0, 242, 255);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .table-wrapper {
        overflow-x: auto;
        padding: 0 4px;
    }
    
    .professional-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .professional-table th {
        text-align: left;
        padding: 14px 16px;
        color: rgb(0, 242, 255);
        font-size: 13px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid rgba(0, 242, 255, 0.3);
        background: transparent;
    }
    
    .professional-table td {
        padding: 14px 16px;
        color: rgb(255, 255, 255);
        font-size: 14px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        background: transparent;
    }
    
    .professional-table tr:hover td {
        background: rgba(0, 242, 255, 0.03);
    }
    
    .appliance-name i {
        color: rgb(0, 242, 255);
        margin-right: 8px;
    }
    
    .usage-value {
        color: rgb(0, 242, 255);
        font-weight: 600;
    }
    
    .trend-list {
        padding: 20px 24px;
    }
    
    .trend-item {
        margin-bottom: 20px;
    }
    
    .trend-date {
        font-size: 13px;
        color: rgb(255, 255, 255);
        margin-bottom: 6px;
    }
    
    .trend-date i {
        color: rgb(0, 242, 255);
        margin-right: 6px;
    }
    
    .trend-value {
        font-size: 14px;
        color: rgb(0, 242, 255);
        margin-bottom: 6px;
    }
    
    .trend-bar {
        height: 6px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        overflow: hidden;
    }
    
    .trend-fill {
        height: 100%;
        background: linear-gradient(90deg, rgb(0, 242, 255), rgb(0, 255, 136));
        border-radius: 10px;
        transition: width 1s ease;
    }
    
    .insights-list {
        padding: 20px 24px;
    }
    
    .insight-item {
        display: flex;
        gap: 14px;
        padding: 14px;
        background: rgba(0, 242, 255, 0.05);
        border-left: 3px solid rgb(0, 242, 255);
        border-radius: 12px;
        margin-bottom: 12px;
        transition: all 0.2s;
    }
    
    .insight-item.warning {
        background: rgba(255, 107, 107, 0.08);
        border-left-color: rgb(255, 107, 107);
    }
    
    .insight-item.critical {
        background: rgba(255, 70, 70, 0.15);
        border-left-color: rgb(255, 68, 68);
    }
    
    .insight-item.success {
        background: rgba(0, 255, 136, 0.08);
        border-left-color: rgb(0, 255, 136);
    }
    
    .insight-item.info {
        background: rgba(0, 242, 255, 0.05);
        border-left-color: rgb(0, 242, 255);
    }
    
    .insight-item.savings-highlight {
        background: rgba(0, 255, 136, 0.1);
        border-left-color: rgb(0, 255, 136);
    }
    
    .insight-item i {
        font-size: 18px;
        color: rgb(0, 242, 255);
        margin-top: 2px;
    }
    
    .insight-item.warning i {
        color: rgb(255, 107, 107);
    }
    
    .insight-item.critical i {
        color: rgb(255, 68, 68);
    }
    
    .insight-item.success i {
        color: rgb(0, 255, 136);
    }
    
    .insight-item.savings-highlight i {
        color: rgb(0, 255, 136);
    }
    
    .insight-item strong {
        color: rgb(255, 255, 255);
        font-size: 14px;
        display: block;
        margin-bottom: 4px;
    }
    
    .insight-item p {
        color: rgb(255, 255, 255);
        font-size: 13px;
        margin: 0;
        line-height: 1.4;
    }
    
    .empty-state {
        text-align: center;
        padding: 50px 20px;
    }
    
    .empty-state i {
        font-size: 48px;
        color: rgb(0, 242, 255);
        opacity: 0.5;
        margin-bottom: 15px;
    }
    
    .empty-state p {
        color: rgb(255, 255, 255);
        margin-bottom: 20px;
    }
    
    .empty-state-mini {
        text-align: center;
        padding: 40px 20px;
    }
    
    .empty-state-mini i {
        font-size: 36px;
        color: rgb(0, 242, 255);
        opacity: 0.5;
        margin-bottom: 12px;
    }
    
    .empty-state-mini p {
        color: rgb(255, 255, 255);
        margin-bottom: 5px;
    }
    
    .empty-state-mini span {
        color: rgb(154, 171, 194);
        font-size: 12px;
    }
    
    .btn-primary-small {
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        color: rgb(255, 255, 255);
        padding: 10px 24px;
        border-radius: 25px;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        display: inline-block;
        transition: all 0.2s;
    }
    
    .btn-primary-small:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 200, 255, 0.3);
        color: rgb(255, 255, 255);
        text-decoration: none;
    }
    
    .eco-banner {
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(0, 242, 255, 0.05));
        border: 1px solid rgba(0, 242, 255, 0.3);
        border-radius: 20px;
        padding: 20px 25px;
        display: flex;
        align-items: center;
        gap: 20px;
        text-align: left;
        margin-top: 40px;
    }
    
    .eco-banner i {
        font-size: 40px;
        color: rgb(0, 242, 255);
    }
    
    .eco-banner h5 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 5px 0;
    }
    
    .eco-banner p {
        color: rgb(255, 255, 255);
        margin: 0;
        font-size: 13px;
    }
    
    .g-4 {
        --bs-gutter-y: 1.5rem;
        --bs-gutter-x: 1.5rem;
    }
    
    .mb-5 {
        margin-bottom: 2rem;
    }
    
    @media (max-width: 768px) {
        .stats-card {
            padding: 15px;
        }
        
        .stats-value {
            font-size: 22px;
        }
        
        .section-header {
            padding: 15px 18px;
        }
        
        .trend-list, .insights-list {
            padding: 15px 18px;
        }
        
        .eco-banner {
            flex-direction: column;
            text-align: center;
            padding: 20px;
        }
    }
    
    @media (max-width: 576px) {
        .stats-card {
            flex-direction: column;
            text-align: center;
        }
        
        .stats-content {
            text-align: center;
        }
        
        .section-header {
            flex-direction: column;
            text-align: center;
        }
        
        .badge {
            align-self: center;
        }
        
        .professional-table th,
        .professional-table td {
            padding: 10px 12px;
            font-size: 12px;
        }
    }
</style>

<?php include("includes/footer.php"); ?>