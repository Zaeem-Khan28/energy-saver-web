<footer style="text-align: center; padding: 20px; background: rgba(3, 6, 12, 0.6); backdrop-filter: blur(12px); border-top: 1px solid rgba(0, 242, 255, 0.25); margin-top: auto; position: relative; z-index: 2; width: 100%;">
    <hr style="border-color: rgba(0, 242, 255, 0.2); margin-bottom: 15px;">
    <p style="color: rgb(154, 171, 194); margin: 0;">⚡ Smart Energy Saver © 2026 | Built for Pakistani Homes 🇵🇰</p>
</footer>

<script src="assets/js/main.js"></script>

<style>
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }
    
    body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }
    
    footer {
        margin-top: auto;
    }
</style>

</body>
</html>