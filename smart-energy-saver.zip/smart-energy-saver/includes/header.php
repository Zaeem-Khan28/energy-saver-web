<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = isset($_SESSION['user_id']);
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Smart Energy Saver</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .navbar a {
            text-decoration: none;
        }

        .navbar .btn {
            position: relative;
            z-index: 9999; 
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark bg-dark px-3 d-flex justify-content-between">

    <a class="navbar-brand" href="index.php">
        ⚡ Energy Saver
    </a>

    <div class="d-flex gap-2">

        <?php if($currentPage == "index.php" && !$isLoggedIn): ?>

            <a href="auth/login.php" class="btn btn-sm btn-outline-light">
                Login
            </a>

            <a href="auth/signup.php" class="btn btn-sm btn-success">
                Signup
            </a>

        <?php elseif($isLoggedIn): ?>

            <a href="dashboard.php" class="btn btn-sm btn-outline-light">Dashboard</a>

            <a href="add_appliance.php" class="btn btn-sm btn-outline-light">➕ Add Appliance</a>

            <a href="tips.php" class="btn btn-sm btn-outline-light">Tips</a>

            <a href="reports.php" class="btn btn-sm btn-outline-light">Reports</a>

            <a href="alerts.php" class="btn btn-sm btn-outline-light">Alerts</a>

            <a href="auth/logout.php" class="btn btn-sm btn-danger">Logout</a>

        <?php endif; ?>

    </div>

</nav>