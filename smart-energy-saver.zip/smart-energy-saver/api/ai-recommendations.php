<?php
include("../config/db.php");

$user_id = $_GET['user_id'];

$q = $conn->query("
    SELECT SUM(units) as total
    FROM appliances
    WHERE user_id='$user_id'
");

$data = $q->fetch_assoc();
$units = $data['total'];

$recommendations = [];

if($units > 300){
    $recommendations[] = "⚠ High consumption detected: Reduce AC usage";
    $recommendations[] = "💡 Switch to inverter AC or limit usage to 6 hours";
}

if($units > 150){
    $recommendations[] = "💡 Replace bulbs with LED for 20% savings";
}

if($units < 100){
    $recommendations[] = "✔ Great job! You're energy efficient";
}

echo json_encode([
    "units" => $units,
    "tips" => $recommendations
]);
?>