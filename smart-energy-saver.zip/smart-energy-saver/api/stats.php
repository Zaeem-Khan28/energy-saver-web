<?php
include("../config/db.php");

$user_id = $_GET['user_id'];

$result = $conn->query("
    SELECT SUM(units) as total 
    FROM appliances 
    WHERE user_id='$user_id'
");

$row = $result->fetch_assoc();
$units = $row['total'];

function bill($u){
    if($u <= 100) return $u * 10;
    if($u <= 200) return $u * 18;
    if($u <= 300) return $u * 25;
    return $u * 35;
}

echo json_encode([
    "units"=>$units,
    "bill"=>bill($units)
]);
?>