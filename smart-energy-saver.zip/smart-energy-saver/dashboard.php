<?php
include("includes/auth-check.php");
include("config/db.php");
include("includes/header.php");

$user_id = $_SESSION['user_id'];

$rate_per_unit = 60; 

$result = $conn->query("
    SELECT 
        name,
        watts,
        hours,
        units,
        created_at
    FROM appliances
    WHERE user_id = '$user_id'
    ORDER BY created_at DESC
");

$total_units = 0;
$highest_usage = 0;
$top_appliance = "";

$labels = [];
$data = [];

if($result){
    while($row = $result->fetch_assoc()){

        $total_units += $row['units'];

        if($row['units'] > $highest_usage){
            $highest_usage = $row['units'];
            $top_appliance = $row['name'];
        }

        $labels[] = date("Y-m-d", strtotime($row['created_at']));
        $data[] = $row['units'];
    }
}

$total_bill = $total_units * $rate_per_unit;
$optimized_bill = $total_bill * 0.75;
$savings = $total_bill - $optimized_bill;
?>

<div class="container mt-4">
  
    <div class="mb-4">
        <h2 style="color: rgb(255, 255, 255); font-size: 28px; font-weight: 600;">
            <i class="fas fa-charging-station" style="color: rgb(0, 242, 255); margin-right: 12px;"></i>
            Smart Energy Dashboard
        </h2>
        <p style="color: rgb(154, 171, 194); margin-top: 8px;">Track your energy consumption, view analytics, and get AI-powered recommendations</p>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-bolt"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Total Units Consumed</span>
                    <h3 class="stats-value"><?= round($total_units, 2) ?> <span>kWh</span></h3>
                    <span class="stats-trend">Total energy usage</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-rupee-sign"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Estimated Bill</span>
                    <h3 class="stats-value">Rs. <?= number_format($total_bill, 2) ?></h3>
                    <span class="stats-trend">Monthly electricity cost</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-12">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(255, 107, 107, 0.1);">
                    <i class="fas fa-fire"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Highest Usage</span>
                    <h3 class="stats-value" style="font-size: 22px;"><?= $top_appliance ?: 'No Data' ?></h3>
                    <span class="stats-trend">Top consuming appliance</span>
                </div>
            </div>
        </div>
    </div>

    <div class="section-card mb-5">
        <div class="section-header">
            <i class="fas fa-chart-line"></i>
            <h4>Energy Consumption Trend</h4>
            <span class="badge">Daily kWh Usage</span>
        </div>
        <div class="chart-container">
            <canvas id="energyChart"></canvas>
        </div>
    </div>
    <div class="row g-4 mb-5">
       
        <div class="col-lg-7">
            <div class="section-card tips-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-robot"></i>
                    <h4>AI Energy Optimization Tips</h4>
                </div>
                
                <div class="tips-list">
                    <?php if($highest_usage > 100): ?>
                        <div class="tip-item warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <div>
                                <strong>⚠ High Energy Alert</strong>
                                <p><?= htmlspecialchars($top_appliance) ?> is consuming <?= round($highest_usage, 2) ?> kWh/day. Consider reducing usage time or upgrading to energy-efficient models.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($total_units > 300): ?>
                        <div class="tip-item">
                            <i class="fas fa-lightbulb"></i>
                            <div>
                                <strong>💡 Switch to LED Lighting</strong>
                                <p>LED bulbs consume up to 80% less energy than traditional incandescent bulbs and last 25x longer.</p>
                            </div>
                        </div>
                        <div class="tip-item">
                            <i class="fas fa-plug"></i>
                            <div>
                                <strong>🔌 Unplug Idle Devices</strong>
                                <p>Electronics on standby mode consume 5-10% of your total electricity bill. Unplug when not in use.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($total_units > 500): ?>
                        <div class="tip-item warning">
                            <i class="fas fa-bell"></i>
                            <div>
                                <strong>🚨 Critical Usage Alert</strong>
                                <p>Your consumption is very high. Reduce AC usage, optimize appliance timing, and consider energy audits.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($total_units <= 300 && $total_units > 0): ?>
                        <div class="tip-item success">
                            <i class="fas fa-check-circle"></i>
                            <div>
                                <strong>✅ Great Job!</strong>
                                <p>Your energy consumption is well-managed. Keep up the good habits and continue monitoring.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="tip-item">
                        <i class="fas fa-thermometer-half"></i>
                        <div>
                            <strong>❄️ Optimal AC Settings</strong>
                            <p>Set your AC temperature between 24-26°C for maximum efficiency. Every degree lower increases energy use by 6-8%.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-sun"></i>
                        <div>
                            <strong>☀️ Natural Lighting</strong>
                            <p>Utilize natural daylight during peak hours to reduce artificial lighting costs.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-star"></i>
                        <div>
                            <strong>⭐ Energy Star Ratings</strong>
                            <p>When buying new appliances, choose higher star ratings to save up to 30% on energy costs.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="section-card savings-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-chart-line"></i>
                    <h4>Savings Impact Analysis</h4>
                </div>
                
                <div class="savings-stats">
                    <div class="savings-row">
                        <span class="savings-label">Current Monthly Bill</span>
                        <span class="savings-value current">Rs. <?= number_format($total_bill, 2) ?></span>
                    </div>
                    <div class="savings-row">
                        <span class="savings-label">After AI Optimization</span>
                        <span class="savings-value optimized">Rs. <?= number_format($optimized_bill, 2) ?></span>
                    </div>
                    <div class="savings-divider"></div>
                    <div class="savings-row highlight">
                        <span class="savings-label">Monthly Savings Potential</span>
                        <span class="savings-value save">Rs. <?= number_format($savings, 2) ?></span>
                    </div>
                    <div class="savings-row">
                        <span class="savings-label">Annual Savings</span>
                        <span class="savings-value save" style="font-size: 20px;">Rs. <?= number_format($savings * 12, 2) ?></span>
                    </div>
                    <div class="progress-container">
                        <div class="progress-label">
                            <span>Reduction Potential</span>
                            <span>Target: 25%</span>
                        </div>
                        <div class="progress-bar-custom">
                            <div class="progress-fill" style="width: 25%;"></div>
                        </div>
                    </div>
                    <div class="savings-tips">
                        <i class="fas fa-lightbulb"></i>
                        <span>Follow AI recommendations to achieve maximum savings</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="eco-banner">
        <i class="fas fa-leaf"></i>
        <div>
            <h5>Together We Can Make a Difference</h5>
            <p>Every kilowatt saved contributes to a greener, more sustainable Pakistan. Start saving today!</p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
let labels = <?= json_encode($labels) ?>;
let data = <?= json_encode($data) ?>;

if(labels.length > 0 && data.length > 0) {
    new Chart(document.getElementById("energyChart"), {
        type: "line",
        data: {
            labels: labels,
            datasets: [{
                label: "Daily Energy Consumption (kWh)",
                data: data,
                borderColor: "rgb(0, 242, 255)",
                backgroundColor: "rgba(0, 242, 255, 0.1)",
                fill: true,
                tension: 0.4,
                pointBackgroundColor: "rgb(0, 242, 255)",
                pointBorderColor: "rgb(255, 255, 255)",
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: "rgb(255, 255, 255)",
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: "rgba(12, 20, 30, 0.95)",
                    titleColor: "rgb(0, 242, 255)",
                    bodyColor: "rgb(255, 255, 255)",
                    borderColor: "rgb(0, 242, 255)",
                    borderWidth: 1
                }
            },
            scales: {
                y: {
                    grid: {
                        color: "rgba(255, 255, 255, 0.1)"
                    },
                    ticks: {
                        color: "rgb(255, 255, 255)",
                        callback: function(value) {
                            return value + " kWh";
                        }
                    },
                    title: {
                        display: true,
                        text: "Energy (kWh)",
                        color: "rgb(154, 171, 194)"
                    }
                },
                x: {
                    grid: {
                        color: "rgba(255, 255, 255, 0.1)"
                    },
                    ticks: {
                        color: "rgb(255, 255, 255)"
                    },
                    title: {
                        display: true,
                        text: "Date",
                        color: "rgb(154, 171, 194)"
                    }
                }
            }
        }
    });
} else {
    document.getElementById("energyChart").innerHTML = '<div style="text-align: center; padding: 50px; color: rgb(255, 255, 255);"><i class="fas fa-chart-line" style="font-size: 48px; margin-bottom: 15px;"></i><p>No data available. Add appliances to see your energy consumption chart.</p></div>';
}
</script>

<style>
    
    .stats-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 18px;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .stats-card:hover {
        transform: translateY(-3px);
        border-color: rgba(0, 242, 255, 0.5);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }
    
    .stats-icon {
        width: 55px;
        height: 55px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .stats-icon i {
        font-size: 28px;
        color: rgb(0, 242, 255);
    }
    
    .stats-content {
        flex: 1;
    }
    
    .stats-label {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgb(255, 255, 255);
        font-weight: 500;
    }
    
    .stats-value {
        font-size: 28px;
        font-weight: 700;
        color: rgb(0, 242, 255);
        margin: 5px 0;
        line-height: 1.2;
    }
    
    .stats-value span {
        font-size: 14px;
        color: rgb(255, 255, 255);
        font-weight: 400;
    }
    
    .stats-trend {
        font-size: 11px;
        color: rgb(154, 171, 194);
    }
    
    .section-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .section-card:hover {
        border-color: rgba(0, 242, 255, 0.4);
    }
    
    .section-header {
        padding: 18px 24px;
        border-bottom: 1px solid rgba(0, 242, 255, 0.2);
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .section-header i {
        font-size: 20px;
        color: rgb(0, 242, 255);
    }
    
    .section-header h4 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0;
        flex: 1;
    }
    
    .badge {
        background: rgba(0, 242, 255, 0.15);
        color: rgb(0, 242, 255);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .chart-container {
        padding: 20px;
        height: 400px;
        position: relative;
    }
    
    .tips-list {
        padding: 20px 24px;
    }
    
    .tip-item {
        display: flex;
        gap: 14px;
        padding: 14px;
        background: rgba(0, 242, 255, 0.05);
        border-left: 3px solid rgb(0, 242, 255);
        border-radius: 12px;
        margin-bottom: 12px;
        transition: all 0.2s;
    }
    
    .tip-item.warning {
        background: rgba(255, 107, 107, 0.08);
        border-left-color: rgb(255, 107, 107);
    }
    
    .tip-item.success {
        background: rgba(0, 255, 136, 0.08);
        border-left-color: rgb(0, 255, 136);
    }
    
    .tip-item i {
        font-size: 18px;
        color: rgb(0, 242, 255);
        margin-top: 2px;
    }
    
    .tip-item.warning i {
        color: rgb(255, 107, 107);
    }
    
    .tip-item.success i {
        color: rgb(0, 255, 136);
    }
    
    .tip-item strong {
        color: rgb(255, 255, 255);
        font-size: 14px;
        display: block;
        margin-bottom: 4px;
    }
    
    .tip-item p {
        color: rgb(255, 255, 255);
        font-size: 13px;
        margin: 0;
        line-height: 1.4;
    }
    
    .savings-card {
        background: linear-gradient(135deg, rgba(12, 20, 30, 0.95), rgba(0, 50, 70, 0.85));
    }
    
    .savings-stats {
        padding: 20px 24px;
    }
    
    .savings-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 0;
    }
    
    .savings-label {
        color: rgb(255, 255, 255);
        font-size: 14px;
    }
    
    .savings-value {
        font-size: 20px;
        font-weight: 700;
    }
    
    .savings-value.current {
        color: rgb(255, 107, 107);
    }
    
    .savings-value.optimized {
        color: rgb(0, 242, 255);
    }
    
    .savings-value.save {
        color: rgb(0, 255, 136);
        font-size: 24px;
    }
    
    .savings-divider {
        height: 1px;
        background: rgba(0, 242, 255, 0.2);
        margin: 8px 0;
    }
    
    .savings-row.highlight {
        background: rgba(0, 255, 136, 0.1);
        margin: 10px -8px;
        padding: 12px 8px;
        border-radius: 12px;
    }
    
    .progress-container {
        margin-top: 20px;
    }
    
    .progress-label {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: rgb(255, 255, 255);
        margin-bottom: 8px;
    }
    
    .progress-bar-custom {
        height: 8px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        overflow: hidden;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, rgb(0, 242, 255), rgb(0, 255, 136));
        border-radius: 10px;
        transition: width 1s ease;
    }
    
    .savings-tips {
        margin-top: 20px;
        padding: 12px;
        background: rgba(0, 242, 255, 0.08);
        border-radius: 12px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 12px;
        color: rgb(255, 255, 255);
    }
    
    .savings-tips i {
        color: rgb(0, 242, 255); 
        font-size: 14px;
    }
    
    .eco-banner {
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(0, 242, 255, 0.05));
        border: 1px solid rgba(0, 242, 255, 0.3);
        border-radius: 20px;
        padding: 20px 25px;
        display: flex;
        align-items: center;
        gap: 20px;
        text-align: left;
        margin-top: 40px;
    }
    
    .eco-banner i {
        font-size: 40px;
        color: rgb(0, 242, 255);
    }
    
    .eco-banner h5 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 5px 0;
    }
    
    .eco-banner p {
        color: rgb(255, 255, 255);
        margin: 0;
        font-size: 13px;
    }
    
    .g-4 {
        --bs-gutter-y: 1.5rem;
        --bs-gutter-x: 1.5rem;
    }
    
    .mb-5 {
        margin-bottom: 2rem;
    }
    
    @media (max-width: 768px) {
        .stats-card {
            padding: 15px;
        }
        
        .stats-value {
            font-size: 22px;
        }
        
        .section-header {
            padding: 15px 18px;
        }
        
        .tips-list {
            padding: 15px 18px;
        }
        
        .savings-stats {
            padding: 15px 18px;
        }
        
        .chart-container {
            height: 300px;
            padding: 15px;
        }
        
        .eco-banner {
            flex-direction: column;
            text-align: center;
            padding: 20px;
        }
    }
    
    @media (max-width: 576px) {
        .stats-card {
            flex-direction: column;
            text-align: center;
        }
        
        .stats-content {
            text-align: center;
        }
        
        .section-header {
            flex-direction: column;
            text-align: center;
        }
        
        .badge {
            align-self: center;
        }
    }
</style>

<?php include("includes/footer.php"); ?>