<?php
include("includes/auth-check.php");
include("config/db.php");
include("includes/header.php");

$user_id = $_SESSION['user_id'];

$rate_per_unit = 60;

$result = $conn->query("
    SELECT name, watts, hours, units 
    FROM appliances 
    WHERE user_id = '$user_id'
");

$total_units = 0;
$highest = 0;
$top_appliance = "";
$appliances_list = [];

while($row = $result->fetch_assoc()){
    $total_units += $row['units'];
    $appliances_list[] = $row;
    
    if($row['units'] > $highest){
        $highest = $row['units'];
        $top_appliance = $row['name'];
    }
}

$current_bill = $total_units * $rate_per_unit;
$optimized_bill = $current_bill * 0.75;
$saving = $current_bill - $optimized_bill;
$saving_percentage = 25;
?>

<div class="container mt-4">
    <div class="mb-4">
        <h2 style="color: rgb(255, 255, 255); font-size: 28px; font-weight: 600;">
            <i class="fas fa-lightbulb" style="color: rgb(0, 242, 255); margin-right: 12px;"></i>
            Smart Energy Tips
        </h2>
        <p style="color: rgb(154, 171, 194); margin-top: 8px;">Track your energy consumption and get AI-powered recommendations to save money</p>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-charging-station"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Total Consumption</span>
                    <h3 class="stats-value"><?= round($total_units, 2) ?> <span>kWh</span></h3>
                    <span class="stats-trend">Daily energy usage</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-rupee-sign"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Estimated Bill</span>
                    <h3 class="stats-value">Rs. <?= number_format($current_bill, 2) ?></h3>
                    <span class="stats-trend">Monthly estimate</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-12">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(255, 107, 107, 0.1);">
                    <i class="fas fa-fire"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Highest Usage</span>
                    <h3 class="stats-value" style="font-size: 22px;"><?= $top_appliance ?: 'No Data' ?></h3>
                    <span class="stats-trend">Top consuming appliance</span>
                </div>
            </div>
        </div>
    </div>

    <div class="section-card mb-5">
        <div class="section-header">
            <i class="fas fa-list"></i>
            <h4>Your Appliances</h4>
            <a href="add_appliance.php" class="btn-add">
                <i class="fas fa-plus"></i> Add New
            </a>
        </div>
        
        <?php if(count($appliances_list) > 0): ?>
            <div class="table-wrapper">
                <table class="professional-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Appliance Name</th>
                            <th>Power (Watts)</th>
                            <th>Hours/Day</th>
                            <th>Daily Usage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; foreach($appliances_list as $appliance): ?>
                        <tr>
                            <td><?= $count++ ?></td>
                            <td>
                                <div class="appliance-name">
                                    <i class="fas fa-microchip"></i>
                                    <?= htmlspecialchars($appliance['name']) ?>
                                </div>
                            </td>
                            <td><?= number_format($appliance['watts'], 0) ?> W</td>
                            <td><?= number_format($appliance['hours'], 1) ?> hrs</td>
                            <td class="usage-value"><?= number_format($appliance['units'], 2) ?> kWh</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-plug"></i>
                <p>No appliances found</p>
                <a href="add_appliance.php" class="btn-primary-small">Add Your First Appliance</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-lg-7">
            <div class="section-card tips-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-robot"></i>
                    <h4>AI Energy Optimization Tips</h4>
                </div>
                
                <div class="tips-list">
                    <?php if($highest > 100): ?>
                        <div class="tip-item warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <div>
                                <strong>High Energy Alert</strong>
                                <p><?= htmlspecialchars($top_appliance) ?> consumes <?= round($highest, 2) ?> kWh/day. Reduce usage time.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($total_units > 300): ?>
                        <div class="tip-item">
                            <i class="fas fa-lightbulb"></i>
                            <div>
                                <strong>Switch to LED</strong>
                                <p>LED bulbs consume up to 80% less energy than traditional bulbs.</p>
                            </div>
                        </div>
                        <div class="tip-item">
                            <i class="fas fa-plug"></i>
                            <div>
                                <strong>Unplug Devices</strong>
                                <p>Standby power accounts for 5-10% of your electricity bill.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if($total_units > 500): ?>
                        <div class="tip-item warning">
                            <i class="fas fa-bell"></i>
                            <div>
                                <strong>Critical Usage Alert</strong>
                                <p>High consumption detected. Reduce AC usage and consider energy-efficient alternatives.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="tip-item">
                        <i class="fas fa-sun"></i>
                        <div>
                            <strong>Natural Lighting</strong>
                            <p>Use daylight instead of artificial lights during daytime hours.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-thermometer-half"></i>
                        <div>
                            <strong>Optimal AC Temperature</strong>
                            <p>Keep AC at 24-26°C for maximum efficiency and lower bills.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-star"></i>
                        <div>
                            <strong>Energy Star Ratings</strong>
                            <p>Use appliances with higher star ratings to save up to 30% energy.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="section-card savings-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-chart-line"></i>
                    <h4>Savings Impact Analysis</h4>
                </div>
                
                <div class="savings-stats">
                    <div class="savings-row">
                        <span class="savings-label">Current Bill</span>
                        <span class="savings-value current">Rs. <?= number_format($current_bill, 2) ?></span>
                    </div>
                    <div class="savings-row">
                        <span class="savings-label">After Optimization</span>
                        <span class="savings-value optimized">Rs. <?= number_format($optimized_bill, 2) ?></span>
                    </div>
                    <div class="savings-divider"></div>
                    <div class="savings-row highlight">
                        <span class="savings-label">You Can Save</span>
                        <span class="savings-value save">Rs. <?= number_format($saving, 2) ?></span>
                    </div>
                    <div class="progress-container">
                        <div class="progress-label">
                            <span><?= $saving_percentage ?>% Reduction Potential</span>
                            <span>Target: 25%</span>
                        </div>
                        <div class="progress-bar-custom">
                            <div class="progress-fill" style="width: <?= $saving_percentage ?>%;"></div>
                        </div>
                    </div>
                    <p class="savings-note">
                        <i class="fas fa-info-circle"></i> Follow AI suggestions to achieve these savings
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="eco-banner">
        <i class="fas fa-leaf"></i>
        <div>
            <h5>Together We Can Make a Difference</h5>
            <p>Every kilowatt saved contributes to a greener, more sustainable Pakistan</p>
        </div>
    </div>
</div>

<style>
    .stats-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 18px;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .stats-card:hover {
        transform: translateY(-3px);
        border-color: rgba(0, 242, 255, 0.5);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }
    
    .stats-icon {
        width: 55px;
        height: 55px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 242, 255, 0.1);
    }
    
    .stats-icon i {
        font-size: 28px;
        color: rgb(0, 242, 255);
    }
    
    .stats-content {
        flex: 1;
    }
    
    .stats-label {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgb(154, 171, 194);
        font-weight: 500;
    }
    
    .stats-value {
        font-size: 28px;
        font-weight: 700;
        color: rgb(0, 242, 255);
        margin: 5px 0;
        line-height: 1.2;
    }
    
    .stats-value span {
        font-size: 14px;
        color: rgb(255, 255, 255);
        font-weight: 400;
    }
    
    .stats-trend {
        font-size: 11px;
        color: rgb(124, 142, 163);
    }
    
    .section-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .section-card:hover {
        border-color: rgba(0, 242, 255, 0.4);
    }
    
    .section-header {
        padding: 18px 24px;
        border-bottom: 1px solid rgba(0, 242, 255, 0.2);
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .section-header i {
        font-size: 20px;
        color: rgb(0, 242, 255);
    }
    
    .section-header h4 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0;
        flex: 1;
    }
    
    .btn-add {
        background: rgba(0, 242, 255, 0.1);
        border: 1px solid rgba(0, 242, 255, 0.3);
        color: rgb(0, 242, 255);
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 500;
        text-decoration: none;
        transition: all 0.2s;
    }
    
    .btn-add:hover {
        background: rgba(0, 242, 255, 0.2);
        color: rgb(0, 242, 255);
        text-decoration: none;
    }
    
    .table-wrapper {
        overflow-x: auto;
        padding: 0 4px;
    }
    
    .professional-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .professional-table th {
        text-align: left;
        padding: 14px 16px;
        color: rgb(0, 242, 255);
        font-size: 13px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid rgba(0, 242, 255, 0.3);
    }
    
    .professional-table td {
        padding: 14px 16px;
        color: rgb(255, 255, 255);
        font-size: 14px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    
    .professional-table tr:hover td {
        background: rgba(0, 242, 255, 0.03);
    }
    
    .appliance-name i {
        color: rgb(0, 242, 255);
        margin-right: 8px;
    }
    
    .usage-value {
        color: rgb(0, 242, 255);
        font-weight: 600;
    }
    
    .tips-list {
        padding: 20px 24px;
    }
    
    .tip-item {
        display: flex;
        gap: 14px;
        padding: 14px;
        background: rgba(0, 242, 255, 0.05);
        border-left: 3px solid rgb(0, 242, 255);
        border-radius: 12px;
        margin-bottom: 12px;
        transition: all 0.2s;
    }
    
    .tip-item.warning {
        background: rgba(255, 107, 107, 0.08);
        border-left-color: rgb(255, 107, 107);
    }
    
    .tip-item i {
        font-size: 18px;
        color: rgb(0, 242, 255);
        margin-top: 2px;
    }
    
    .tip-item.warning i {
        color: rgb(255, 107, 107);
    }
    
    .tip-item strong {
        color: rgb(255, 255, 255);
        font-size: 14px;
        display: block;
        margin-bottom: 4px;
    }
    
    .tip-item p {
        color: rgb(154, 171, 194);
        font-size: 13px;
        margin: 0;
        line-height: 1.4;
    }
    
    .savings-card {
        background: linear-gradient(135deg, rgba(12, 20, 30, 0.95), rgba(0, 50, 70, 0.85));
    }
    
    .savings-stats {
        padding: 20px 24px;
    }
    
    .savings-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 0;
    }
    
    .savings-label {
        color: rgb(154, 171, 194);
        font-size: 14px;
    }
    
    .savings-value {
        font-size: 20px;
        font-weight: 700;
    }
    
    .savings-value.current {
        color: rgb(255, 107, 107);
    }
    
    .savings-value.optimized {
        color: rgb(0, 242, 255);
    }
    
    .savings-value.save {
        color: rgb(0, 255, 136);
        font-size: 24px;
    }
    
    .savings-divider {
        height: 1px;
        background: rgba(0, 242, 255, 0.2);
        margin: 8px 0;
    }
    
    .savings-row.highlight {
        background: rgba(0, 255, 136, 0.1);
        margin: 10px -8px;
        padding: 12px 8px;
        border-radius: 12px;
    }
    
    .progress-container {
        margin-top: 20px;
    }
    
    .progress-label {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: rgb(154, 171, 194);
        margin-bottom: 8px;
    }
    
    .progress-bar-custom {
        height: 8px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        overflow: hidden;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, rgb(0, 242, 255), rgb(0, 255, 136));
        border-radius: 10px;
        transition: width 1s ease;
    }
    
    .savings-note {
        font-size: 12px;
        color: rgb(124, 142, 163);
        margin-top: 20px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .empty-state {
        text-align: center;
        padding: 50px 20px;
    }
    
    .empty-state i {
        font-size: 48px;
        color: rgb(0, 242, 255);
        opacity: 0.5;
        margin-bottom: 15px;
    }
    
    .empty-state p {
        color: rgb(154, 171, 194);
        margin-bottom: 20px;
    }
    
    .btn-primary-small {
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        color: rgb(255, 255, 255);
        padding: 10px 24px;
        border-radius: 25px;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        display: inline-block;
        transition: all 0.2s;
    }
    
    .btn-primary-small:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 200, 255, 0.3);
        color: rgb(255, 255, 255);
        text-decoration: none;
    }
    
    .eco-banner {
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(0, 242, 255, 0.05));
        border: 1px solid rgba(0, 242, 255, 0.3);
        border-radius: 20px;
        padding: 20px 25px;
        display: flex;
        align-items: center;
        gap: 20px;
        text-align: left;
        margin-top: 40px;
    }
    
    .eco-banner i {
        font-size: 40px;
        color: rgb(0, 242, 255);
    }
    
    .eco-banner h5 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 5px 0;
    }
    
    .eco-banner p {
        color: rgb(154, 171, 194);
        margin: 0;
        font-size: 13px;
    }
    
    @media (max-width: 768px) {
        .stats-card {
            padding: 15px;
        }
        
        .stats-value {
            font-size: 22px;
        }
        
        .section-header {
            padding: 15px 18px;
        }
        
        .tips-list {
            padding: 15px 18px;
        }
        
        .savings-stats {
            padding: 15px 18px;
        }
        
        .eco-banner {
            flex-direction: column;
            text-align: center;
            padding: 20px;
        }
        
        .professional-table th,
        .professional-table td {
            padding: 10px 12px;
            font-size: 12px;
        }
    }
    
    @media (max-width: 576px) {
        .stats-card {
            flex-direction: column;
            text-align: center;
        }
        
        .stats-content {
            text-align: center;
        }
        
        .section-header {
            flex-direction: column;
            text-align: center;
        }
        
        .btn-add {
            align-self: center;
        }
    }
    
    .g-4 {
        --bs-gutter-y: 1.5rem;
        --bs-gutter-x: 1.5rem;
    }
    
    .mb-5 {
        margin-bottom: 2rem;
    }
</style>

<?php include("includes/footer.php"); ?>