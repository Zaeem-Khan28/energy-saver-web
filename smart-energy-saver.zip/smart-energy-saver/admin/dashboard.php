<?php include("../includes/auth-check.php"); include("../config/db.php"); ?>

<h2>🛠 Admin Dashboard</h2>

<div class="container">

<div class="card p-3">
<?php
$totalUsers = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc();
$totalUsage = $conn->query("SELECT SUM(units) as u FROM appliances")->fetch_assoc();

echo "👥 Total Users: ".$totalUsers['c']."<br>";
echo "⚡ Total Energy Recorded: ".$totalUsage['u']." kWh";
?>
</div>

</div>