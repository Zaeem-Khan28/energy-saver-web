<?php include("../config/db.php"); ?>

<h2>👥 Users List</h2>

<table border="1" class="table table-dark">
<tr>
<th>ID</th><th>Name</th><th>Email</th>
</tr>

<?php
$res = $conn->query("SELECT * FROM users");

while($row = $res->fetch_assoc()){
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['name']}</td>
        <td>{$row['email']}</td>
    </tr>";
}
?>
</table>