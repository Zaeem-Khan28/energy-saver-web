<?php include("includes/header.php"); ?>

<div class="container mt-4">
    <h2>📩 Contact Us</h2>

    <form class="card p-3">
        <input class="form-control mb-2" placeholder="Your Name">
        <input class="form-control mb-2" placeholder="Email">
        <textarea class="form-control mb-2" placeholder="Message"></textarea>
        <button class="btn btn-success">Send</button>
    </form>
</div>

<?php include("includes/footer.php"); ?>