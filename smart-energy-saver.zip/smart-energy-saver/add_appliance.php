<?php
include("includes/auth-check.php");
include("config/db.php");
include("includes/header.php");

$success = "";
$error = "";

if(isset($_POST['add'])){

    $name = trim($_POST['name']);
    $watts = (float) $_POST['watts'];
    $hours = (float) $_POST['hours'];

    $uid = $_SESSION['user_id'];

    if(empty($name) || $watts <= 0 || $hours <= 0){
        $error = "Please enter valid appliance details.";
    } else {

        $units = ($watts * $hours) / 1000;

        $stmt = $conn->prepare("
            INSERT INTO appliances (user_id, name, watts, hours, units, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");

        $stmt->bind_param("isddd", $uid, $name, $watts, $hours, $units);

        if($stmt->execute()){
            $success = "Appliance added successfully!";
        } else {
            $error = "Database error occurred.";
        }
    }
}

if(isset($_POST['delete'])){
    $appliance_id = (int) $_POST['appliance_id'];
    $uid = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("DELETE FROM appliances WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $appliance_id, $uid);
    
    if($stmt->execute()){
        $success = "Appliance deleted successfully!";
    } else {
        $error = "Error deleting appliance.";
    }
}
$uid = $_SESSION['user_id'];
$appliances = [];
$total_units = 0;
$total_cost = 0;
$cost_per_unit = 25; 

$result = $conn->query("SELECT * FROM appliances WHERE user_id = $uid ORDER BY created_at DESC");

if($result && $result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $appliances[] = $row;
        $total_units += $row['units'];
    }
    $total_cost = $total_units * $cost_per_unit;
}
?>

<div class="container mt-4">
    <h2 style="color: rgb(255, 255, 255); margin-bottom: 25px;">➕ Add Appliance</h2>

    <?php if($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8 col-lg-6">
            <form method="POST" class="card p-4 shadow-lg" style="background: rgba(12, 20, 30, 0.85); backdrop-filter: blur(10px); border: 1px solid rgba(0, 242, 255, 0.3); border-radius: 1rem;">
                
                <div class="row">
                    <div class="col-12 mb-3">
                        <label style="color: rgb(255, 255, 255); font-weight: 500; margin-bottom: 8px;">
                            <i class="fas fa-plug"></i> Appliance Name
                        </label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. AC, Fan, Light" required 
                               style="background: rgba(2, 10, 22, 0.9); border: 1px solid rgba(0, 242, 255, 0.3); color: rgb(255, 255, 255); border-radius: 10px; padding: 12px;">
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label style="color: rgb(255, 255, 255); font-weight: 500; margin-bottom: 8px;">
                            <i class="fas fa-bolt"></i> Power (Watts)
                        </label>
                        <input type="number" name="watts" class="form-control" placeholder="e.g. 1000" required 
                               style="background: rgba(2, 10, 22, 0.9); border: 1px solid rgba(0, 242, 255, 0.3); color: rgb(255, 255, 255); border-radius: 10px; padding: 12px;">
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label style="color: #fff; font-weight: 500; margin-bottom: 8px;">
                            <i class="fas fa-clock"></i> Hours Used Per Day
                        </label>
                        <input type="number" name="hours" class="form-control" placeholder="e.g. 5" required 
                               style="background: rgba(2, 10, 22, 0.9); border: 1px solid rgba(0, 242, 255, 0.3); color: rgb(255, 255, 255); border-radius: 10px; padding: 12px;">
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 mt-2">
                        <button class="btn btn-success w-100" name="add" style="background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255)); border: none; padding: 12px; font-weight: 600; border-radius: 10px;">
                            Calculate & Save
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
        <div class="col-md-4 col-lg-6">
            <div class="card p-4" style="background: rgba(12, 20, 30, 0.65); backdrop-filter: blur(10px); border: 1px solid rgba(0, 242, 255, 0.3); border-radius: 1rem; height: 100%;">
                <h4 style="color: rgb(0, 242, 255); margin-bottom: 15px;">
                    <i class="fas fa-info-circle"></i> Quick Guide
                </h4>
                <p style="color: rgb(203, 218, 233); line-height: 1.6;">
                    <strong style="color: rgb(255, 255, 255);">How to calculate energy usage:</strong><br>
                    • <strong style="color: rgb(0, 242, 255);">Watts</strong> × <strong style="color: rgb(0, 242, 255);">Hours</strong> ÷ 1000 = <strong style="color: #00f2ff;">kWh/day</strong><br>
                    • Example: 1000W AC × 5 hours = 5 kWh/day
                </p>
                <hr style="border-color: rgba(0, 242, 255, 0.2);">
                <p style="color: rgb(203, 218, 233); font-size: 0.9rem;">
                    <i class="fas fa-lightbulb"></i> Tip: Add all your appliances to track total energy consumption.
                </p>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-12">
            <div class="card p-4" style="background: rgba(12, 20, 30, 0.85); backdrop-filter: blur(10px); border: 1px solid rgba(0, 242, 255, 0.3); border-radius: 1rem;">
                <h3 style="color: rgb(255, 255, 255); margin-bottom: 20px;">
                    <i class="fas fa-list"></i> Your Appliances
                </h3>
                
                <?php if(count($appliances) > 0): ?>
                   
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="p-3 rounded" style="background: rgba(0, 242, 255, 0.1); border-left: 3px solid rgb(0, 242, 255);">
                                <small style="color: rgb(255, 255, 255);">Total Daily Consumption</small>
                                <h4 style="color: rgb(0, 242, 255); margin: 5px 0;"><?= number_format($total_units, 2) ?> kWh</h4>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 rounded" style="background: rgba(0, 242, 255, 0.1); border-left: 3px solid #00f2ff;">
                                <small style="color: rgb(255, 255, 255);">Estimated Daily Cost</small>
                                <h4 style="color: rgb(0, 242, 255); margin: 5px 0;">Rs. <?= number_format($total_cost, 2) ?></h4>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table" style="color: rgb(255, 255, 255); margin-bottom: 0;">
                            <thead style="border-bottom: 2px solid rgba(0, 242, 255, 0.3);">
                                <tr>
                                    <th style="color: rgb(0, 242, 255); padding: 12px; background: transparent;">#</th>
                                    <th style="color: rgb(0, 242, 255); padding: 12px; background: transparent;">Appliance Name</th>
                                    <th style="color: rgb(0, 242, 255); padding: 12px; background: transparent;">Watts (W)</th>
                                    <th style="color: rgb(0, 242, 255); padding: 12px; background: transparent;">Hours/Day</th>
                                    <th style="color: rgb(0, 242, 255); padding: 12px; background: transparent;">kWh/Day</th>
                                    <th style="color: rgb(0, 242, 255); padding: 12px; background: transparent;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $count = 1; foreach($appliances as $appliance): ?>
                                <tr style="border-bottom: 1px solid rgba(255, 255, 255, 0.15); background: transparent;">
                                    <td style="padding: 12px; background: transparent; color: rgb(255, 255, 255);"><?= $count++ ?></td>
                                    <td style="padding: 12px; background: transparent; color: rgb(255, 255, 255);">
                                        <i class="fas fa-microchip" style="color: rgb(0, 242, 255); margin-right: 8px;"></i>
                                        <?= htmlspecialchars($appliance['name']) ?>
                                    </td>
                                    <td style="padding: 12px; background: transparent; color: rgb(255, 255, 255);"><?= number_format($appliance['watts'], 0) ?> W</td>
                                    <td style="padding: 12px; background: transparent; color: rgb(255, 255, 255);"><?= number_format($appliance['hours'], 1) ?> hrs</td>
                                    <td style="padding: 12px; background: transparent;">
                                        <strong style="color: rgb(0, 242, 255);"><?= number_format($appliance['units'], 2) ?> kWh</strong>
                                    </td>
                                    <td style="padding: 12px; background: transparent;">
                                        <form method="POST" style="display: inline-block;" onsubmit="return confirm('Delete this appliance?');">
                                            <input type="hidden" name="appliance_id" value="<?= $appliance['id'] ?>">
                                            <button type="submit" name="delete" class="btn btn-sm" style="background: rgba(255, 70, 90, 0.2); border: 1px solid #ff4d6d; color: #ff6b8b; border-radius: 8px; padding: 5px 12px;">
                                                <i class="fas fa-trash-alt"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center p-5" style="color: rgb(255, 255, 255);">
                        <i class="fas fa-plug" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.5;"></i>
                        <p>No appliances added yet. Use the form above to add your first appliance!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
    .form-control:focus {
        border-color: rgb(0, 242, 255) !important;
        box-shadow: 0 0 8px rgba(0, 242, 255, 0.3) !important;
        outline: none;
    }
    
    .form-control::placeholder {
        color: #6c7c94 !important;
    }
    
    input[type="number"]::-webkit-inner-spin-button, 
    input[type="number"]::-webkit-outer-spin-button {
        opacity: 0.5;
    }
    
    .table-hover tbody tr:hover {
        background: rgba(0, 242, 255, 0.05) !important;
    }
    
    .table tbody tr {
        background: transparent !important;
    }
    
    .table td, .table th {
        background: transparent !important;
    }
    
    .card .table td,
    .card .table th,
    .card .table td * {
        color: rgb(255, 255, 255) !important;
    }
    
    .card .row .col-md-6 small {
        color: rgb(255, 255, 255) !important;
    }
</style>

<?php include("includes/footer.php"); ?>