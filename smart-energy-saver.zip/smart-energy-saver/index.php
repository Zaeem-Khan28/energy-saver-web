<?php include("includes/header.php"); ?>

<style>
    body {
        padding-top: 70px;
        background: radial-gradient(circle at 20% 30%, rgb(10, 15, 30), rgb(3, 6, 12));
    }
    
    .hero-section {
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.08), rgba(0, 0, 0, 0.3));
        position: relative;
        overflow: hidden;
        margin-top: -70px;
        padding: 120px 0 80px;
        min-height: 90vh;
        display: flex;
        align-items: center;
    }
    
    .hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="rgba(0,242,255,0.03)" d="M45.3,-77.2C59.8,-68.9,73.1,-56.3,80.5,-40.6C87.9,-24.9,89.4,-6.2,85.1,10.8C80.8,27.8,70.7,43.1,58.2,55.7C45.7,68.3,30.7,78.2,13.2,82.7C-4.3,87.2,-24.5,86.3,-40.9,78.6C-57.3,70.9,-70,56.4,-78.2,39.2C-86.4,22,-90.1,2.1,-86.2,-15.9C-82.3,-33.9,-70.8,-50,-56.2,-62.1C-41.6,-74.2,-23.9,-82.3,-4.2,-77.1C15.5,-71.9,30.9,-85.5,45.3,-77.2Z" transform="translate(100 100)"/></svg>') repeat;
        opacity: 0.3;
        pointer-events: none;
    }
    
    .hero-content {
        text-align: center;
        max-width: 900px;
        margin: 0 auto;
        position: relative;
        z-index: 2;
    }
    
    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: rgba(0, 242, 255, 0.2);
        backdrop-filter: blur(10px);
        padding: 10px 24px;
        border-radius: 60px;
        font-size: 14px;
        font-weight: 500;
        color: rgb(0, 242, 255);
        margin-bottom: 30px;
        border: 1px solid rgba(0, 242, 255, 0.3);
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { box-shadow: 0 0 0 0 rgba(0, 242, 255, 0.4); }
        50% { box-shadow: 0 0 0 10px rgba(0, 242, 255, 0); }
    }
    
    .hero-badge i {
        font-size: 16px;
    }
    
    .hero-title {
        font-size: 64px;
        font-weight: 800;
        color: rgb(255, 255, 255);
        margin-bottom: 20px;
        line-height: 1.2;
    }
    
    .gradient-text {
        background: linear-gradient(135deg, rgb(0, 242, 255), rgb(0, 255, 136), rgb(0, 195, 255));
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        animation: gradientShift 3s ease infinite;
        background-size: 200% 200%;
    }
    
    @keyframes gradientShift {
        0%, 100% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
    }
    
    .hero-description {
        font-size: 18px;
        color: rgb(224, 230, 240);
        line-height: 1.6;
        margin-bottom: 35px;
        max-width: 700px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .hero-buttons {
        display: flex;
        gap: 20px;
        justify-content: center;
        margin-bottom: 40px;
        flex-wrap: wrap;
    }
    
    .btn-primary-custom {
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        padding: 14px 38px;
        border-radius: 50px;
        color: rgb(255, 255, 255);
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
        font-size: 16px;
        box-shadow: 0 4px 15px rgba(0, 195, 255, 0.3);
    }
    
    .btn-primary-custom:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 200, 255, 0.5);
        color: rgb(255, 255, 255);
        text-decoration: none;
    }
    
    .btn-outline-custom {
        background: transparent;
        border: 2px solid rgb(0, 242, 255);
        padding: 14px 38px;
        border-radius: 50px;
        color: rgb(0, 242, 255);
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
        font-size: 16px;
    }
    
    .btn-outline-custom:hover {
        background: rgb(0, 242, 255);
        color: rgb(3, 6, 12);
        transform: translateY(-3px);
        text-decoration: none;
        box-shadow: 0 5px 20px rgba(0, 242, 255, 0.4);
    }
    
    .hero-features {
        display: flex;
        gap: 30px;
        justify-content: center;
        flex-wrap: wrap;
    }
    
    .hero-features span {
        color: rgb(255, 255, 255);
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 8px;
        background: rgba(255, 255, 255, 0.05);
        padding: 8px 18px;
        border-radius: 40px;
    }
    
    .hero-features i {
        color: rgb(0, 255, 136);
        font-size: 14px;
    }
    
    .section-header {
        text-align: center;
        margin-bottom: 50px;
    }
    
    .section-header h2 {
        color: rgb(255, 255, 255);
        font-size: 36px;
        font-weight: 700;
        margin-bottom: 12px;
    }
    
    .section-header p {
        color: rgb(154, 171, 194);
        font-size: 16px;
    }
    
    .feature-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 30px 25px;
        text-align: center;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .feature-card:hover {
        transform: translateY(-8px);
        border-color: rgba(0, 242, 255, 0.6);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
    }
    
    .feature-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(0, 242, 255, 0.05));
        border-radius: 25px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        transition: all 0.3s ease;
    }
    
    .feature-card:hover .feature-icon {
        transform: scale(1.05);
        background: rgba(0, 242, 255, 0.2);
    }
    
    .feature-icon i {
        font-size: 36px;
        color: rgb(0, 242, 255);
    }
    
    .feature-card h4 {
        color: rgb(255, 255, 255);
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 12px;
    }
    
    .feature-card p {
        color: rgb(184, 199, 224);
        font-size: 14px;
        line-height: 1.5;
        margin: 0;
    }
    
    .step-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 35px 25px;
        text-align: center;
        position: relative;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .step-card:hover {
        transform: translateY(-5px);
        border-color: rgba(0, 242, 255, 0.5);
    }
    
    .step-number {
        position: absolute;
        top: -18px;
        left: 25px;
        width: 40px;
        height: 40px;
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        color: rgb(255, 255, 255);
        font-size: 18px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    }
    
    .step-icon {
        font-size: 45px;
        color: rgb(0, 242, 255);
        margin-bottom: 20px;
    }
    
    .step-card h4 {
        color: rgb(255, 255, 255);
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 12px;
    }
    
    .step-card p {
        color: rgb(184, 199, 224);
        font-size: 14px;
        margin: 0;
    }
    
    .impact-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 30px 20px;
        text-align: center;
        transition: all 0.3s ease;
    }
    
    .impact-card:hover {
        transform: translateY(-5px);
        border-color: rgba(0, 242, 255, 0.5);
    }
    
    .impact-number {
        font-size: 42px;
        font-weight: 800;
        color: rgb(0, 242, 255);
        margin-bottom: 10px;
    }
    
    .impact-card p {
        color: rgb(255, 255, 255);
        font-size: 14px;
        margin: 0;
    }
    
    .insight-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 25px;
        text-align: center;
        transition: all 0.3s ease;
    }
    
    .insight-card:hover {
        transform: translateY(-5px);
        border-color: rgba(0, 242, 255, 0.5);
    }
    
    .insight-card i {
        font-size: 42px;
        color: rgb(0, 242, 255);
        margin-bottom: 15px;
    }
    
    .insight-card h4 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
    }
    
    .insight-card p {
        color: rgb(184, 199, 224);
        font-size: 13px;
        margin: 0;
    }
    
    .coach-card {
        background: linear-gradient(135deg, rgba(12, 20, 30, 0.95), rgba(0, 50, 70, 0.9));
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.4);
        border-radius: 28px;
        padding: 45px 35px;
        text-align: center;
    }
    
    .coach-header {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
        margin-bottom: 25px;
        flex-wrap: wrap;
    }
    
    .coach-header i {
        font-size: 42px;
        color: rgb(0, 242, 255);
    }
    
    .coach-header h2 {
        color: rgb(255, 255, 255);
        font-size: 30px;
        font-weight: 700;
        margin: 0;
    }
    
    .coach-description {
        color: rgb(224, 230, 240);
        font-size: 16px;
        margin-bottom: 35px;
    }
    
    .tips-list {
        text-align: left;
        max-width: 550px;
        margin: 0 auto 35px;
    }
    
    .tip-item {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 12px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .tip-item i {
        font-size: 20px;
        color: rgb(0, 242, 255);
    }
    
    .tip-item span {
        color: rgb(255, 255, 255);
        font-size: 14px;
        line-height: 1.4;
    }
    
    .btn-coach {
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        padding: 14px 38px;
        border-radius: 50px;
        color: rgb(255, 255, 255);
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
        font-size: 16px;
    }
    
    .btn-coach:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 200, 255, 0.5);
        color: rgb(255, 255, 255);
        text-decoration: none;
    }
    
    .cta-card {
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.2), rgba(0, 242, 255, 0.05));
        border: 1px solid rgba(0, 242, 255, 0.4);
        border-radius: 28px;
        padding: 55px 30px;
        text-align: center;
    }
    
    .cta-icon {
        font-size: 55px;
        color: rgb(0, 242, 255);
        margin-bottom: 20px;
    }
    
    .cta-card h2 {
        color: rgb(255, 255, 255);
        font-size: 34px;
        font-weight: 700;
        margin-bottom: 15px;
    }
    
    .cta-card p {
        color: rgb(224, 230, 240);
        font-size: 16px;
        margin-bottom: 30px;
    }
    
    .btn-cta {
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        padding: 16px 48px;
        border-radius: 50px;
        color: rgb(255, 255, 255);
        font-weight: 600;
        font-size: 18px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
        box-shadow: 0 5px 20px rgba(0, 195, 255, 0.4);
    }
    
    .btn-cta:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(0, 200, 255, 0.6);
        color: rgb(255, 255, 255);
        text-decoration: none;
    }
    
    .g-4 {
        --bs-gutter-y: 1.5rem;
        --bs-gutter-x: 1.5rem;
    }
    
    .mt-5 {
        margin-top: 4rem;
    }
    
    .mb-5 {
        margin-bottom: 4rem;
    }
    
    .container {
        max-width: 1280px;
        margin: 0 auto;
        padding: 0 20px;
    }
    
    @media (max-width: 992px) {
        .hero-title {
            font-size: 48px;
        }
        
        .section-header h2 {
            font-size: 32px;
        }
    }
    
    @media (max-width: 768px) {
        body {
            padding-top: 60px;
        }
        
        .hero-section {
            padding: 100px 0 60px;
            min-height: auto;
        }
        
        .hero-title {
            font-size: 36px;
        }
        
        .hero-description {
            font-size: 16px;
        }
        
        .hero-buttons {
            flex-direction: column;
            align-items: center;
        }
        
        .hero-features {
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }
        
        .section-header h2 {
            font-size: 28px;
        }
        
        .coach-card {
            padding: 30px 20px;
        }
        
        .coach-header h2 {
            font-size: 24px;
        }
        
        .cta-card h2 {
            font-size: 26px;
        }
        
        .cta-card {
            padding: 40px 20px;
        }
        
        .btn-cta {
            font-size: 16px;
            padding: 14px 32px;
        }
    }
    
    @media (max-width: 576px) {
        .hero-title {
            font-size: 28px;
        }
        
        .hero-badge {
            font-size: 12px;
            padding: 6px 16px;
        }
        
        .feature-card, .step-card, .impact-card, .insight-card {
            padding: 20px;
        }
        
        .feature-icon {
            width: 65px;
            height: 65px;
        }
        
        .feature-icon i {
            font-size: 30px;
        }
    }
</style>

<div class="hero-section">
    <div class="container">
        <div class="hero-content">
            <div class="hero-badge">
                <i class="fas fa-robot"></i> AI-Powered Energy Management
            </div>
            <h1 class="hero-title">Smart Energy <span class="gradient-text">AI</span></h1>
            <p class="hero-description">
                Your personal AI energy advisor for Pakistani homes 🇵🇰
                <br>
                Save electricity, reduce bills, and track everything in real-time.
            </p>
            <div class="hero-buttons">
                <a href="auth/signup.php" class="btn-primary-custom">
                    <i class="fas fa-rocket"></i> Start Free
                </a>
                <a href="auth/login.php" class="btn-outline-custom">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
            </div>
            <div class="hero-features">
                <span><i class="fas fa-check-circle"></i> No credit card required</span>
                <span><i class="fas fa-gem"></i> Free forever plan</span>
                <span><i class="fas fa-shield-alt"></i> 100% secure</span>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="section-header">
        <h2>🚀 Powerful Features</h2>
        <p>Everything you need to monitor and optimize your energy consumption</p>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h4>Live Analytics</h4>
                <p>Track real-time electricity consumption with smart charts and detailed insights.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-robot"></i>
                </div>
                <h4>AI Recommendations</h4>
                <p>Get smart suggestions to reduce your electricity bill automatically.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-simple"></i>
                </div>
                <h4>Bill Predictor</h4>
                <p>Estimate your monthly electricity bill based on real usage patterns.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-microchip"></i>
                </div>
                <h4>Appliance Tracking</h4>
                <p>Monitor each appliance's consumption separately for better control.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h4>Mobile Friendly</h4>
                <p>Fully responsive design that works perfectly on all devices.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h4>24/7 Monitoring</h4>
                <p>Continuous AI monitoring to help you stay on top of your energy usage.</p>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="section-header">
        <h2>⚙ How It Works</h2>
        <p>Three simple steps to start saving energy</p>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="step-card">
                <div class="step-number">1</div>
                <i class="fas fa-plus-circle step-icon"></i>
                <h4>Add Appliances</h4>
                <p>Enter watts and daily usage hours for each appliance</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="step-card">
                <div class="step-number">2</div>
                <i class="fas fa-calculator step-icon"></i>
                <h4>AI Calculates</h4>
                <p>System automatically calculates energy consumption</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="step-card">
                <div class="step-number">3</div>
                <i class="fas fa-money-bill-wave step-icon"></i>
                <h4>Save Money</h4>
                <p>Get personalized tips and reduce your bill instantly</p>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="section-header">
        <h2>📈 Live Impact</h2>
        <p>Real results from our growing community</p>
    </div>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="impact-card">
                <div class="impact-number">10K+</div>
                <p>Units Saved</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="impact-card">
                <div class="impact-number">5K+</div>
                <p>Active Users</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="impact-card">
                <div class="impact-number">30%</div>
                <p>Avg Bill Reduction</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="impact-card">
                <div class="impact-number">24/7</div>
                <p>AI Monitoring</p>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="section-header">
        <h2>Why Choose Smart Energy AI?</h2>
        <p>Built specifically for Pakistani households</p>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h4>Real-Time Tracking</h4>
                <p>Har appliance ka live energy usage track hota hai.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <h4>AI Smart Suggestions</h4>
                <p>System automatically batata hai kaise bill kam karein.</p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-flag-checkered"></i>
                </div>
                <h4>Pakistan Optimized</h4>
                <p>WAPDA slabs aur PKR billing system fully integrated.</p>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="section-header">
        <h2>📊 Live Energy Insights</h2>
        <p>What our AI is learning from real user data</p>
    </div>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="insight-card">
                <i class="fas fa-wind"></i>
                <h4>High Usage</h4>
                <p>AC & Fridge dominate consumption</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="insight-card">
                <i class="fas fa-lightbulb"></i>
                <h4>Saving Tip</h4>
                <p>Switch to LED → save 30%</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="insight-card">
                <i class="fas fa-chart-line"></i>
                <h4>Trend</h4>
                <p>Usage decreasing this week</p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="insight-card">
                <i class="fas fa-gauge-high"></i>
                <h4>Efficiency</h4>
                <p>Efficiency score improving</p>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="coach-card">
        <div class="coach-header">
            <i class="fas fa-robot"></i>
            <h2>AI Energy Coach</h2>
        </div>
        <p class="coach-description">
            Our AI analyzes your electricity usage and gives smart savings tips automatically.
        </p>
        
        <div class="tips-list">
            <div class="tip-item">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Reduce AC usage by 2 hours daily → Save up to 15% on bill</span>
            </div>
            <div class="tip-item">
                <i class="fas fa-lightbulb"></i>
                <span>Replace bulbs with LED → Save PKR 800/month</span>
            </div>
            <div class="tip-item">
                <i class="fas fa-plug"></i>
                <span>Unplug idle devices at night → Reduce standby power waste</span>
            </div>
            <div class="tip-item">
                <i class="fas fa-sun"></i>
                <span>Use natural daylight instead of bulbs → Save energy during peak hours</span>
            </div>
        </div>
        
        <a href="auth/signup.php" class="btn-coach">
            <i class="fas fa-robot"></i> Activate AI Coach
        </a>
    </div>
</div>

<div class="container mt-5 mb-5">
    <div class="cta-card">
        <i class="fas fa-bolt cta-icon"></i>
        <h2>Ready to Cut Your Electricity Bill?</h2>
        <p>Join thousands of Pakistani households saving electricity with Smart Energy AI.</p>
        <a href="auth/signup.php" class="btn-cta">
            <i class="fas fa-user-plus"></i> Create Free Account
        </a>
    </div>
</div>

<?php include("includes/footer.php"); ?>