<?php
include("includes/auth-check.php");
include("config/db.php");
include("includes/header.php");

$uid = $_SESSION['user_id'];

$rate = 60;

$r = $conn->query("
    SELECT SUM(units) as total_units 
    FROM appliances 
    WHERE user_id='$uid'
");

$data = $r->fetch_assoc();
$total_units = $data['total_units'] ?? 0;

$total_bill = $total_units * $rate;

$top = $conn->query("
    SELECT name, SUM(units) as usage_units
    FROM appliances
    WHERE user_id='$uid'
    GROUP BY name
    ORDER BY usage_units DESC
    LIMIT 1
");

$top_appliance = $top->fetch_assoc();
?>

<div class="container mt-4">
    
    <div class="mb-4">
        <h2 style="color: rgb(255, 255, 255); font-size: 28px; font-weight: 600;">
            <i class="fas fa-bell" style="color: rgb(255, 107, 107); margin-right: 12px;"></i>
            Smart Energy Alerts
        </h2>
        <p style="color: rgb(154, 171, 194); margin-top: 8px;">Real-time energy monitoring and AI-powered alert system to optimize your consumption</p>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-bolt"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Total Energy Usage</span>
                    <h3 class="stats-value"><?= round($total_units, 2) ?> <span>kWh</span></h3>
                    <span class="stats-trend">Total consumption</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(0, 242, 255, 0.1);">
                    <i class="fas fa-rupee-sign"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Estimated Bill</span>
                    <h3 class="stats-value">Rs. <?= number_format($total_bill, 2) ?></h3>
                    <span class="stats-trend">Monthly electricity cost</span>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-12">
            <div class="stats-card">
                <div class="stats-icon" style="background: rgba(255, 107, 107, 0.1);">
                    <i class="fas fa-trophy"></i>
                </div>
                <div class="stats-content">
                    <span class="stats-label">Top Appliance</span>
                    <h3 class="stats-value" style="font-size: 22px;"><?= htmlspecialchars($top_appliance['name'] ?? 'No Data') ?></h3>
                    <span class="stats-trend">Highest consuming device</span>
                </div>
            </div>
        </div>
    </div>

    <div class="section-card alert-card mb-5">
        <div class="section-header">
            <i class="fas fa-robot"></i>
            <h4>AI Alert System</h4>
            <span class="badge">Real-time Monitoring</span>
        </div>
        
        <div class="alert-list">
            <?php if($total_units > 500): ?>
                <div class="alert-item critical">
                    <div class="alert-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="alert-content">
                        <strong>🚨 CRITICAL ALERT</strong>
                        <p>Very high electricity consumption detected! Your usage (<?= round($total_units, 2) ?> kWh) exceeds normal household levels significantly.</p>
                        <div class="alert-action">
                            <i class="fas fa-exclamation-triangle"></i> Immediate reduction required in heavy appliances (AC, Heater, Geyser)
                        </div>
                    </div>
                </div>
                
                <div class="alert-item warning">
                    <div class="alert-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="alert-content">
                        <strong>⚠ Top Consumer Alert</strong>
                        <p><?= htmlspecialchars($top_appliance['name'] ?? 'Your top appliance') ?> is consuming the most energy. Consider reducing usage time or upgrading to energy-efficient model.</p>
                    </div>
                </div>
                
            <?php elseif($total_units > 300): ?>
                <div class="alert-item warning">
                    <div class="alert-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>⚠ WARNING: High Energy Usage Detected</strong>
                        <p>Your consumption (<?= round($total_units, 2) ?> kWh) is above average. Immediate optimization recommended.</p>
                        <div class="alert-action">
                            <i class="fas fa-microchip"></i> Try reducing usage of <?= htmlspecialchars($top_appliance['name'] ?? 'high-power appliances') ?>
                        </div>
                    </div>
                </div>
                
            <?php elseif($total_units > 100): ?>
                <div class="alert-item info">
                    <div class="alert-icon">
                        <i class="fas fa-info-circle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>ℹ Moderate Usage Detected</strong>
                        <p>Your consumption (<?= round($total_units, 2) ?> kWh) is in moderate range. You can still optimize to save more.</p>
                        <div class="alert-action">
                            <i class="fas fa-chart-simple"></i> Small changes can lead to significant savings
                        </div>
                    </div>
                </div>
                
            <?php elseif($total_units > 0): ?>
                <div class="alert-item success">
                    <div class="alert-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="alert-content">
                        <strong>✅ Excellent!</strong>
                        <p>Your energy consumption (<?= round($total_units, 2) ?> kWh) is under control. Great job maintaining efficiency!</p>
                        <div class="alert-action">
                            <i class="fas fa-leaf"></i> Keep up the good habits
                        </div>
                    </div>
                </div>
                
            <?php else: ?>
                <div class="alert-item info">
                    <div class="alert-icon">
                        <i class="fas fa-plug"></i>
                    </div>
                    <div class="alert-content">
                        <strong>No Appliances Added</strong>
                        <p>Add your appliances to receive personalized energy alerts and recommendations.</p>
                        <a href="add_appliance.php" class="btn-mini">Add Your First Appliance →</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row g-4 mb-5">
       
        <div class="col-lg-7">
            <div class="section-card tips-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-lightbulb"></i>
                    <h4>Energy Saving Tips</h4>
                    <span class="badge">Smart Recommendations</span>
                </div>
                
                <div class="tips-grid">
                    <div class="tip-item">
                        <i class="fas fa-plug"></i>
                        <div>
                            <strong>Unplug Idle Devices</strong>
                            <p>Electronics on standby consume 5-10% of your electricity bill. Unplug when not in use.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-lightbulb"></i>
                        <div>
                            <strong>Switch to LED Lights</strong>
                            <p>LED bulbs use up to 80% less energy and last 25x longer than traditional bulbs.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <strong>Avoid Peak Hours</strong>
                            <p>Minimize heavy appliance usage during peak evening hours (6 PM - 10 PM) to reduce load.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-thermometer-half"></i>
                        <div>
                            <strong>Optimize AC Temperature</strong>
                            <p>Set AC to 24-26°C. Every degree lower increases energy consumption by 6-8%.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-snowflake"></i>
                        <div>
                            <strong>Maintain Appliances</strong>
                            <p>Regular maintenance of ACs, refrigerators, and other appliances improves efficiency by 15-20%.</p>
                        </div>
                    </div>
                    
                    <div class="tip-item">
                        <i class="fas fa-star"></i>
                        <div>
                            <strong>Energy Star Ratings</strong>
                            <p>Choose appliances with higher star ratings when buying new ones to save up to 30% energy.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="section-card insight-card" style="height: 100%;">
                <div class="section-header">
                    <i class="fas fa-chart-pie"></i>
                    <h4>Quick Insight</h4>
                </div>
                
                <div class="insight-content">
                    <?php if($total_units > 300): ?>
                        <div class="insight-badge warning-badge">
                            <i class="fas fa-exclamation-circle"></i>
                            High Consumption Alert
                        </div>
                        <div class="insight-stats">
                            <div class="insight-number"><?= round($total_units, 2) ?> <span>kWh</span></div>
                            <div class="insight-label">Current Usage</div>
                        </div>
                        <div class="insight-message">
                            <i class="fas fa-chart-line"></i>
                            <p>Your bill is <strong>higher than average households</strong>. Immediate optimization recommended.</p>
                        </div>
                        <div class="savings-calc">
                            <div class="savings-title">
                                <i class="fas fa-money-bill-wave"></i>
                                Potential Savings
                            </div>
                            <div class="savings-amount">Up to <strong>Rs. <?= number_format($total_bill * 0.25, 2) ?></strong> per month</div>
                            <div class="savings-bar">
                                <div class="savings-fill" style="width: 75%;"></div>
                            </div>
                            <div class="savings-text">20-30% reduction possible with optimization</div>
                        </div>
                        
                    <?php elseif($total_units > 100): ?>
                        <div class="insight-badge moderate-badge">
                            <i class="fas fa-chart-line"></i>
                            Moderate Consumption
                        </div>
                        <div class="insight-stats">
                            <div class="insight-number"><?= round($total_units, 2) ?> <span>kWh</span></div>
                            <div class="insight-label">Current Usage</div>
                        </div>
                        <div class="insight-message">
                            <i class="fas fa-smile"></i>
                            <p>Your consumption is <strong>moderate and balanced</strong>. With small optimizations, you can save even more.</p>
                        </div>
                        <div class="savings-calc">
                            <div class="savings-title">
                                <i class="fas fa-money-bill-wave"></i>
                                Potential Savings
                            </div>
                            <div class="savings-amount">Up to <strong>Rs. <?= number_format($total_bill * 0.15, 2) ?></strong> per month</div>
                            <div class="savings-bar">
                                <div class="savings-fill" style="width: 45%;"></div>
                            </div>
                            <div class="savings-text">15% reduction possible with optimization</div>
                        </div>
                        
                    <?php elseif($total_units > 0): ?>
                        <div class="insight-badge success-badge">
                            <i class="fas fa-check-circle"></i>
                            Efficient Consumption
                        </div>
                        <div class="insight-stats">
                            <div class="insight-number"><?= round($total_units, 2) ?> <span>kWh</span></div>
                            <div class="insight-label">Current Usage</div>
                        </div>
                        <div class="insight-message">
                            <i class="fas fa-trophy"></i>
                            <p>Your energy consumption is <strong>efficient and well-managed</strong>. Great job!</p>
                        </div>
                        <div class="savings-calc">
                            <div class="savings-title">
                                <i class="fas fa-leaf"></i>
                                Keep It Up
                            </div>
                            <div class="savings-amount">You're already saving <strong>energy & money</strong></div>
                            <div class="savings-text">Continue these good habits to maintain efficiency</div>
                        </div>
                        
                    <?php else: ?>
                        <div class="insight-badge info-badge">
                            <i class="fas fa-info-circle"></i>
                            No Data Available
                        </div>
                        <div class="insight-message">
                            <i class="fas fa-plug"></i>
                            <p>Add appliances to get personalized insights and recommendations.</p>
                        </div>
                        <a href="add_appliance.php" class="btn-add-appliance">Add Your First Appliance →</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="eco-banner">
        <i class="fas fa-leaf"></i>
        <div>
            <h5>🌱 Smart Energy = Smart Savings</h5>
            <p>Every unit saved contributes to a greener Pakistan. Join thousands of households optimizing their energy consumption!</p>
        </div>
    </div>
</div>

<style>
   
    .stats-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 18px;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .stats-card:hover {
        transform: translateY(-3px);
        border-color: rgba(0, 242, 255, 0.5);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }
    
    .stats-icon {
        width: 55px;
        height: 55px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .stats-icon i {
        font-size: 28px;
        color: rgb(0, 242, 255);
    }
    
    .stats-content {
        flex: 1;
    }
    
    .stats-label {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgb(255, 255, 255);
        font-weight: 500;
    }
    
    .stats-value {
        font-size: 28px;
        font-weight: 700;
        color: rgb(0, 242, 255);
        margin: 5px 0;
        line-height: 1.2;
    }
    
    .stats-value span {
        font-size: 14px;
        color: rgb(255, 255, 255);
        font-weight: 400;
    }
    
    .stats-trend {
        font-size: 11px;
        color: rgb(154, 171, 194);
    }
    
    .section-card {
        background: rgba(12, 20, 30, 0.85);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 242, 255, 0.25);
        border-radius: 20px;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    
    .section-card:hover {
        border-color: rgba(0, 242, 255, 0.4);
    }
    
    .section-header {
        padding: 18px 24px;
        border-bottom: 1px solid rgba(0, 242, 255, 0.2);
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .section-header i {
        font-size: 20px;
        color: rgb(0, 242, 255);
    }
    
    .section-header h4 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0;
        flex: 1;
    }
    
    .badge {
        background: rgba(0, 242, 255, 0.15);
        color: rgb(0, 242, 255);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .alert-list {
        padding: 20px 24px;
    }
    
    .alert-item {
        display: flex;
        gap: 16px;
        padding: 18px;
        border-radius: 16px;
        margin-bottom: 16px;
        transition: all 0.2s;
    }
    
    .alert-item.critical {
        background: rgba(255, 70, 70, 0.15);
        border: 1px solid rgba(255, 70, 70, 0.3);
    }
    
    .alert-item.warning {
        background: rgba(255, 107, 107, 0.12);
        border: 1px solid rgba(255, 107, 107, 0.25);
    }
    
    .alert-item.info {
        background: rgba(0, 242, 255, 0.08);
        border: 1px solid rgba(0, 242, 255, 0.2);
    }
    
    .alert-item.success {
        background: rgba(0, 255, 136, 0.08);
        border: 1px solid rgba(0, 255, 136, 0.25);
    }
    
    .alert-icon i {
        font-size: 28px;
    }
    
    .alert-item.critical .alert-icon i { color: rgb(255, 68, 68); }
    .alert-item.warning .alert-icon i { color: rgb(255, 107, 107); }
    .alert-item.info .alert-icon i { color: rgb(0, 242, 255); }
    .alert-item.success .alert-icon i { color: rgb(0, 255, 136); }
    
    .alert-content {
        flex: 1;
    }
    
    .alert-content strong {
        color: rgb(255, 255, 255);
        font-size: 16px;
        display: block;
        margin-bottom: 8px;
    }
    
    .alert-content p {
        color: rgb(255, 255, 255);
        font-size: 14px;
        margin-bottom: 12px;
        line-height: 1.5;
    }
    
    .alert-action {
        background: rgba(0, 0, 0, 0.3);
        padding: 8px 12px;
        border-radius: 10px;
        font-size: 13px;
        color: rgb(255, 255, 255);
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-mini {
        display: inline-block;
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        color: white;
        padding: 8px 20px;
        border-radius: 20px;
        text-decoration: none;
        font-size: 13px;
        margin-top: 8px;
        transition: all 0.2s;
    }
    
    .btn-mini:hover {
        transform: translateY(-2px);
        color: white;
        text-decoration: none;
    }
    
    .tips-grid {
        padding: 20px 24px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 12px;
    }
    
    .tip-item {
        display: flex;
        gap: 12px;
        padding: 12px;
        background: rgba(0, 242, 255, 0.05);
        border-left: 3px solid rgb(0, 242, 255);
        border-radius: 12px;
        transition: all 0.2s;
    }
    
    .tip-item i {
        font-size: 18px;
        color: rgb(0, 242, 255);
        margin-top: 2px;
    }
    
    .tip-item strong {
        color: rgb(255, 255, 255);
        font-size: 13px;
        display: block;
        margin-bottom: 4px;
    }
    
    .tip-item p {
        color: rgb(255, 255, 255);
        font-size: 12px;
        margin: 0;
        line-height: 1.4;
    }
    
    .insight-content {
        padding: 20px 24px;
    }
    
    .insight-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 16px;
        border-radius: 30px;
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 20px;
    }
    
    .warning-badge {
        background: rgba(255, 107, 107, 0.15);
        color: rgb(255, 107, 107);
    }
    
    .moderate-badge {
        background: rgba(0, 242, 255, 0.15);
        color: rgb(0, 242, 255);
    }
    
    .success-badge {
        background: rgba(0, 255, 136, 0.15);
        color: rgb(0, 255, 136);
    }
    
    .info-badge {
        background: rgba(0, 242, 255, 0.1);
        color: rgb(0, 242, 255);
    }
    
    .insight-stats {
        text-align: center;
        margin-bottom: 25px;
    }
    
    .insight-number {
        font-size: 48px;
        font-weight: 800;
        color: rgb(0, 242, 255);
    }
    
    .insight-number span {
        font-size: 18px;
        color: rgb(255, 255, 255);
    }
    
    .insight-label {
        color: rgb(154, 171, 194);
        font-size: 12px;
    }
    
    .insight-message {
        background: rgba(0, 242, 255, 0.05);
        padding: 15px;
        border-radius: 12px;
        margin-bottom: 20px;
        display: flex;
        gap: 12px;
        align-items: flex-start;
    }
    
    .insight-message i {
        font-size: 20px;
        color: rgb(0, 242, 255);
    }
    
    .insight-message p {
        color: rgb(255, 255, 255);
        margin: 0;
        font-size: 13px;
        line-height: 1.5;
    }
    
    .savings-calc {
        background: rgba(0, 0, 0, 0.3);
        padding: 15px;
        border-radius: 12px;
        text-align: center;
    }
    
    .savings-title {
        font-size: 13px;
        color: rgb(154, 171, 194);
        margin-bottom: 8px;
    }
    
    .savings-amount {
        font-size: 18px;
        font-weight: 700;
        color: rgb(0, 255, 136);
        margin-bottom: 12px;
    }
    
    .savings-bar {
        height: 6px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 10px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .savings-fill {
        height: 100%;
        background: linear-gradient(90deg, rgb(0, 242, 255), rgb(0, 255, 136));
        border-radius: 10px;
        transition: width 1s ease;
    }
    
    .savings-text {
        font-size: 11px;
        color: rgb(154, 171, 194);
        margin-top: 8px;
    }
    
    .btn-add-appliance {
        display: block;
        text-align: center;
        background: linear-gradient(95deg, rgb(0, 195, 255), rgb(0, 119, 255));
        color: white;
        padding: 12px;
        border-radius: 12px;
        text-decoration: none;
        margin-top: 20px;
        transition: all 0.2s;
    }
    
    .btn-add-appliance:hover {
        transform: translateY(-2px);
        color: white;
        text-decoration: none;
    }
    
    .eco-banner {
        background: linear-gradient(135deg, rgba(0, 242, 255, 0.15), rgba(0, 242, 255, 0.05));
        border: 1px solid rgba(0, 242, 255, 0.3);
        border-radius: 20px;
        padding: 20px 25px;
        display: flex;
        align-items: center;
        gap: 20px;
        text-align: left;
        margin-top: 40px;
    }
    
    .eco-banner i {
        font-size: 40px;
        color: rgb(0, 242, 255);
    }
    
    .eco-banner h5 {
        color: rgb(255, 255, 255);
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 5px 0;
    }
    
    .eco-banner p {
        color: rgb(255, 255, 255);
        margin: 0;
        font-size: 13px;
    }
    
    .g-4 {
        --bs-gutter-y: 1.5rem;
        --bs-gutter-x: 1.5rem;
    }
    
    .mb-5 {
        margin-bottom: 2rem;
    }
    
    @media (max-width: 768px) {
        .stats-card {
            padding: 15px;
        }
        
        .stats-value {
            font-size: 22px;
        }
        
        .section-header {
            padding: 15px 18px;
        }
        
        .alert-list, .tips-grid, .insight-content {
            padding: 15px 18px;
        }
        
        .tips-grid {
            grid-template-columns: 1fr;
        }
        
        .eco-banner {
            flex-direction: column;
            text-align: center;
            padding: 20px;
        }
        
        .alert-item {
            flex-direction: column;
            text-align: center;
        }
        
        .alert-action {
            display: inline-flex;
        }
    }
    
    @media (max-width: 576px) {
        .stats-card {
            flex-direction: column;
            text-align: center;
        }
        
        .stats-content {
            text-align: center;
        }
        
        .section-header {
            flex-direction: column;
            text-align: center;
        }
        
        .insight-number {
            font-size: 36px;
        }
    }
</style>

<?php include("includes/footer.php"); ?>