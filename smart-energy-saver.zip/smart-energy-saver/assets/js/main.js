function toggleMode(){
    document.body.classList.toggle("light");
    localStorage.setItem("mode",
        document.body.classList.contains("light") ? "light":"dark"
    );
}

window.onload = () => {
    if(localStorage.getItem("mode") === "light"){
        document.body.classList.add("light");
    }
};